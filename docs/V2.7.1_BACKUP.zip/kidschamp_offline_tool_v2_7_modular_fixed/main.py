from app.ui.main_window import KidsChampApp

def main():
    app = KidsChampApp()
    app.mainloop()

if __name__ == "__main__":
    main()
