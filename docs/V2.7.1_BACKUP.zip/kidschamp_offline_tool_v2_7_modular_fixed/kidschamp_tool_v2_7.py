"""Compatibility launcher. The real code is now split inside the app/ folder."""
from main import main

if __name__ == "__main__":
    main()
