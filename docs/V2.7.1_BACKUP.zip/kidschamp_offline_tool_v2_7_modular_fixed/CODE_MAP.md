# Kids Champ V2.7.1 Modular Fixed — Code Map

This version keeps the V2.7 features and behavior, with the Python code split into small files for easier understanding and maintenance. The V2.7.1 package also fixes the missing modular imports/decorator from the first refactor package.

## Start here

- `main.py` — starts the application.
- `run_windows.bat` — normal Windows launcher.
- `build_windows_exe.bat` — builds the Windows EXE.
- `kidschamp_tool_v2_7.py` — tiny compatibility launcher only.

## Core files

### `app/config.py`
Change global app settings here:
- App title
- Maximum batch size (250)
- Colors
- Paths
- Drag-and-drop availability
- Template/icon folders

### `app/models.py`
Simple data structures:
- `Box`
- `Layout`
- `BatchItem`

### `app/filename_parser.py`
Filename and artwork detection:
- Reads `name_city.jpg`
- Reads supported ID/name/city formats
- Removes image extensions
- Detects Portrait / Landscape

If a future filename-reading bug happens, check this file first.

### `app/template_store.py`
Template storage/loading:
- Loads template JSON files
- Finds default Portrait/Landscape templates
- Reloads template settings after admin saves changes

### `app/image_renderer.py`
Final output image generation:
- Fits/fills artwork
- Adds name
- Adds city
- Draws location pin
- Chooses fonts
- Creates output file names

If artwork size, white gap, text placement, pin, or final PNG has a problem, check this file.

### `app/file_utils.py`
Small file-system helpers:
- Open folders
- Safe template file names

### `app/ui_helpers.py`
Reusable UI helpers:
- Loads icons
- Creates common buttons
- Changes button colors

## Generator UI files

### `app/ui/main_window.py`
Main app object and application state:
- Starts the window
- Loads icons
- Creates batch state
- Connects all generator/template modules

### `app/ui/generator_layout.py`
Generator page visual layout:
- Header/tabs
- Upload/preview area
- Batch rows
- Search visual controls
- Row display
- Main buttons

If you want to change where a button, panel, label, row, or preview appears, check this file.

### `app/ui/batch_actions.py`
Batch/ZIP operations:
- Upload ZIP
- Load images
- Search/filter
- Auto/Portrait/Landscape selection
- Template reload
- Batch stats

### `app/ui/row_editor.py`
Each artwork row:
- Edit ID
- Edit name
- Edit city
- Edit template mode
- Save changes
- Delete one artwork

If the edit/delete row buttons have a bug, check this file.

### `app/ui/output_actions.py`
Preview and final generation:
- Preview selected artwork
- Validate batch
- Generate all images
- Create bulk ZIP
- Progress/cancel
- Clear all

If Download All / Generate / preview / clear has a bug, check this file.

## Template Settings files

### `app/ui/template_settings.py`
Small connector class that combines all template-setting modules.

### `app/ui/template_layout.py`
Template Settings screen layout:
- Left template list
- Editor controls
- Properties controls
- Buttons

### `app/ui/template_actions.py`
Template file actions:
- New template
- Upload/replace template image
- Delete custom template
- Save template
- Color picker
- Saved template list

If New Template / Save / Delete / Upload has a bug, check this file.

### `app/ui/template_canvas.py`
Visual template editor:
- Draws template preview
- Draws artwork/name/location boxes
- Drag boxes
- Resize boxes
- Location pin preview
- Mouse handling

If drag/resize/alignment is wrong, check this file.

### `app/ui/template_state.py`
Template edit state:
- Undo
- Dirty/saved status
- Restore state
- Property-change state

## Assets and saved templates

- `assets/` — built-in images and icons
- `assets/icons/` — UI icons
- `templates/` — editable template PNG + JSON files

## Easy bug map

| Problem | First file to check |
|---|---|
| Filename/name/city reads wrong | `app/filename_parser.py` |
| Portrait/Landscape detection wrong | `app/filename_parser.py` |
| Artwork has white gap / crop issue | `app/image_renderer.py` |
| Name/city/pin output issue | `app/image_renderer.py` |
| ZIP upload problem | `app/ui/batch_actions.py` |
| Search/filter problem | `app/ui/batch_actions.py` |
| Row edit/delete problem | `app/ui/row_editor.py` |
| Preview/download/generate problem | `app/ui/output_actions.py` |
| Generator UI position/design | `app/ui/generator_layout.py` |
| New template/save/delete problem | `app/ui/template_actions.py` |
| Template drag/resize problem | `app/ui/template_canvas.py` |
| Template screen layout problem | `app/ui/template_layout.py` |

## Important rule

You do not need to combine these files again. Python imports and links them automatically.

Run:

```powershell
py main.py
```

or double-click:

```text
run_windows.bat
```

Editing any linked `.py` file and saving it will be used the next time the app starts.
