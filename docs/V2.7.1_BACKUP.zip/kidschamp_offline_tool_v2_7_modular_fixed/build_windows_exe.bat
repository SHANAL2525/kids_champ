@echo off
cd /d "%~dp0"
title Build Kids Champ Generator V2.7.1 Modular Fixed EXE
where py >nul 2>nul
if %errorlevel%==0 (
    py -m pip install -r requirements.txt
    py -m PyInstaller --noconfirm --clean --onefile --windowed --name KidsChampArtworkGeneratorV2.7.1 --additional-hooks-dir "." --add-data "assets;assets" --add-data "templates;templates" main.py
) else (
    python -m pip install -r requirements.txt
    python -m PyInstaller --noconfirm --clean --onefile --windowed --name KidsChampArtworkGeneratorV2.7.1 --additional-hooks-dir "." --add-data "assets;assets" --add-data "templates;templates" main.py
)
echo.
echo EXE created inside the dist folder.
echo Editable templates are stored in a templates folder beside the EXE.
pause
