# Kids Champ Artwork Generator V2.7.1 — Modular Fixed

This package keeps the same V2.7 features and UI, but the source code is split into smaller Python modules for easier study and maintenance.

## Important correction in V2.7.1

The first modular package had two refactor-only runtime problems:

1. `generator_layout.py` used `TemplateSettingsPanel` without importing it.
2. `_box_values()` lost its original `@staticmethod` decorator while the Template Settings code was separated.

Both are fixed in this package. The original V2.7 functionality has not been intentionally changed.

## Run

Double-click `run_windows.bat`

or from VS Code terminal:

```powershell
py -m pip install -r requirements.txt
py main.py
```

## Code structure

Read `CODE_MAP.md` first. It explains which file controls each feature or bug area.

## Templates

Editable templates stay in the `templates/` folder.

## Test batch

`Sample_Batch_V2_7.zip` is included.

## Verification

See `V2.7.1_TEST_REPORT.txt` for the smoke tests run on this corrected modular package.
