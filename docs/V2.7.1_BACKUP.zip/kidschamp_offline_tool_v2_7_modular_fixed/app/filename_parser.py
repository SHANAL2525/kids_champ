import re
from typing import Tuple
from pathlib import Path
from PIL import Image, ImageOps
from .config import SUPPORTED_EXTENSIONS

def safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*]+', "_", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value or "Untitled"

def strip_image_extensions(value: str) -> str:
    cleaned = value.strip()
    pattern = re.compile(r"(?i)\.(?:jpe?g|png|webp|bmp|tiff?)$")
    while pattern.search(cleaned):
        cleaned = pattern.sub("", cleaned).strip()
    return cleaned

def clean_metadata(value: str) -> str:
    value = strip_image_extensions(value)
    value = value.replace("_", " ")
    value = re.sub(r"\s+", " ", value).strip(" ._-")
    return value

def looks_like_submission_id(value: str) -> bool:
    token = value.strip()
    return bool(token and re.fullmatch(r"(?i)[a-z-]*\d[a-z0-9-]*", token))

def parse_filename(filename: str) -> Tuple[str, str, str, str]:
    stem = strip_image_extensions(Path(filename).stem).strip(" ._-")
    if not stem:
        raise ValueError("The filename is empty")

    double_parts = [part.strip() for part in stem.split("__")]
    if len(double_parts) == 3 and all(double_parts):
        submission_id = clean_metadata(double_parts[0])
        child_name = clean_metadata(double_parts[1])
        city = clean_metadata(double_parts[2])
        parse_format = "ID__Name__City"
    elif len(double_parts) == 2 and all(double_parts):
        submission_id = ""
        child_name = clean_metadata(double_parts[0])
        city = clean_metadata(double_parts[1])
        parse_format = "Name__City"
    elif "__" in stem:
        raise ValueError("Use Name__City or ID__Name__City")
    else:
        tokens = [token.strip() for token in stem.split("_") if token.strip()]
        if len(tokens) < 2:
            raise ValueError("Use Name_City.jpg or ID_Name_City.jpg")
        if len(tokens) >= 3 and looks_like_submission_id(tokens[0]):
            submission_id = clean_metadata(tokens[0])
            child_name = clean_metadata("_".join(tokens[1:-1]))
            city = clean_metadata(tokens[-1])
            parse_format = "ID_Name_City"
        else:
            submission_id = ""
            child_name = clean_metadata("_".join(tokens[:-1]))
            city = clean_metadata(tokens[-1])
            parse_format = "Name_City"

    if not child_name or not city:
        raise ValueError("Child name or city is missing")
    return submission_id, child_name, city, parse_format

def detect_layout(image_path: str) -> str:
    with Image.open(image_path) as image:
        image = ImageOps.exif_transpose(image)
        width, height = image.size
    return "Portrait" if height > width else "Landscape"
