from dataclasses import dataclass

@dataclass
class Box:
    x: int
    y: int
    width: int
    height: int

@dataclass
class Layout:
    template_path: str
    artwork_box: Box
    name_box: Box
    city_box: Box
    name_font_size: int
    city_font_size: int
    text_color: str = "#10344B"
    show_location_pin: bool = True
    location_pin_size: int = 38
    location_pin_gap: int = 12
    artwork_fit_mode: str = "Fill Frame"
    display_name: str = "Template"
    template_type: str = "Any"
    is_default: bool = False

@dataclass
class BatchItem:
    source_path: str
    filename: str
    submission_id: str
    child_name: str
    city: str
    detected_layout: str
    selected_layout: str
    template_mode: str
    parse_format: str
    status: str = "Ready"
    warning: str = ""
