import os
import sys
from pathlib import Path
import tkinter as tk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    ROOT_CLASS = TkinterDnD.Tk
    DND_AVAILABLE = True
except Exception:
    DND_FILES = None
    ROOT_CLASS = tk.Tk
    DND_AVAILABLE = False

APP_TITLE = "Kids Champ Artwork Generator V2.7.1 Modular Fixed"
MAX_BATCH_IMAGES = 250
SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

# Modern admin-style palette.
BG = "#F4F7FB"
CARD = "#FFFFFF"
CARD_ALT = "#F8FAFC"
TEXT = "#172033"
MUTED = "#64748B"
BORDER = "#D7E0EA"
PRIMARY = "#2563EB"
PRIMARY_DARK = "#1D4ED8"
PRIMARY_SOFT = "#E8F0FF"
SUCCESS = "#15803D"
SUCCESS_SOFT = "#E8F7EE"
WARNING = "#B45309"
WARNING_SOFT = "#FFF4E5"
DANGER = "#DC2626"
DANGER_SOFT = "#FEECEC"
PURPLE = "#7C3AED"
ORANGE = "#EA580C"
CHARCOAL = "#202A38"
CHARCOAL_HOVER = "#2C394B"
DOWNLOAD_GREEN = "#16A34A"
DOWNLOAD_GREEN_HOVER = "#15803D"

PROJECT_ROOT = Path(__file__).resolve().parent.parent

def resource_path(relative_path: str) -> str:
    base_path = getattr(sys, "_MEIPASS", str(PROJECT_ROOT))
    return os.path.join(base_path, relative_path)

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = PROJECT_ROOT

BUNDLED_TEMPLATE_DIR = Path(resource_path("templates"))
TEMPLATE_DIR = APP_DIR / "templates"
TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)
ICON_DIR = Path(resource_path(os.path.join("assets", "icons")))
