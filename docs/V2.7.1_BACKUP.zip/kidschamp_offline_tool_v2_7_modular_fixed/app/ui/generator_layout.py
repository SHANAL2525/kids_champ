import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

from .template_settings import TemplateSettingsPanel

class GeneratorLayoutMixin:
    def _configure_styles(self):
            style = ttk.Style(self)
            try:
                style.theme_use("clam")
            except tk.TclError:
                pass
            style.configure("TFrame", background=BG)
            style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
            style.configure("TEntry", fieldbackground=CARD, foreground=TEXT, bordercolor=BORDER, padding=7)
            style.configure("TCombobox", fieldbackground=CARD, background=CARD, foreground=TEXT, padding=6)
            style.configure("TSpinbox", fieldbackground=CARD, background=CARD, foreground=TEXT, padding=6)
            style.configure("Vertical.TScrollbar", background="#CBD5E1", troughcolor="#F1F5F9", arrowcolor=MUTED)
            style.configure(
                "Modern.Treeview",
                background=CARD,
                fieldbackground=CARD,
                foreground=TEXT,
                rowheight=70,
                borderwidth=0,
                font=("Segoe UI", 11),
            )
            style.map("Modern.Treeview", background=[("selected", PRIMARY_SOFT)], foreground=[("selected", TEXT)])
            style.configure(
                "Modern.Treeview.Heading",
                background="#EAF0F7",
                foreground="#334155",
                font=("Segoe UI", 10, "bold"),
                relief="flat",
                padding=(8, 10),
            )
            style.map("Modern.Treeview.Heading", background=[("active", "#DDE7F2")])
            style.configure("Template.Treeview", background=CARD, fieldbackground=CARD, rowheight=58, borderwidth=0, font=("Segoe UI", 10))
            style.map("Template.Treeview", background=[("selected", PRIMARY_SOFT)], foreground=[("selected", TEXT)])
            style.configure("Template.Treeview.Heading", background="#EAF0F7", foreground="#334155", font=("Segoe UI", 9, "bold"), relief="flat")
            style.configure("Horizontal.TProgressbar", troughcolor="#E2E8F0", background=PRIMARY, bordercolor="#E2E8F0", lightcolor=PRIMARY, darkcolor=PRIMARY)

    def _build_ui(self):
            header = tk.Frame(self, bg=CARD, padx=20, pady=12, highlightthickness=1, highlightbackground=BORDER)
            header.pack(fill="x")
            title_wrap = tk.Frame(header, bg=CARD)
            title_wrap.pack(side="left")
            tk.Label(title_wrap, text="Kids Champ Artwork Generator", bg=CARD, fg=TEXT, font=("Segoe UI", 20, "bold")).pack(anchor="w")
            tk.Label(title_wrap, text="Fast offline batch production · up to 250 artworks", bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")

            tab_wrap = tk.Frame(header, bg=CARD)
            tab_wrap.pack(side="right")
            self.generator_tab_button = make_button(
                tab_wrap,
                "Generator",
                lambda: self.show_tab("generator"),
                icon=self.icons.get("generator_white"),
                bg=PRIMARY,
                fg="white",
                active_bg=PRIMARY_DARK,
                border_color=None,
                font=("Segoe UI", 12, "bold"),
                padx=18,
                pady=10,
            )
            self.generator_tab_button.pack(side="left", padx=(0, 6))
            self.settings_tab_button = make_button(
                tab_wrap,
                "Template Settings",
                lambda: self.show_tab("settings"),
                icon=self.icons.get("settings"),
                bg=CARD_ALT,
                fg=TEXT,
                active_bg="#EEF2F7",
                font=("Segoe UI", 12, "bold"),
                padx=18,
                pady=10,
            )
            self.settings_tab_button.pack(side="left")

            self.content = tk.Frame(self, bg=BG)
            self.content.pack(fill="both", expand=True)
            self.generator_page = tk.Frame(self.content, bg=BG)
            self.settings_page = TemplateSettingsPanel(self.content, self)
            self.generator_page.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._build_generator_page()

            status_bar = tk.Frame(self, bg=CARD, padx=12, pady=7, highlightthickness=1, highlightbackground=BORDER)
            status_bar.pack(fill="x", side="bottom")
            tk.Label(status_bar, textvariable=self.status_text, bg=CARD, fg=MUTED, anchor="w", font=("Segoe UI", 9)).pack(fill="x")

    def show_tab(self, name: str):
            if name == "settings":
                self.settings_page.place(relx=0, rely=0, relwidth=1, relheight=1)
                self.settings_page.lift()
                self.settings_tab_button.configure(image=self.icons.get("settings_white"))
                self.generator_tab_button.configure(image=self.icons.get("generator"))
                set_button_colors(self.settings_tab_button, PRIMARY, "white", PRIMARY_DARK)
                set_button_colors(self.generator_tab_button, CARD_ALT, TEXT, "#EEF2F7")
            else:
                self.generator_page.lift()
                self.generator_tab_button.configure(image=self.icons.get("generator_white"))
                self.settings_tab_button.configure(image=self.icons.get("settings"))
                set_button_colors(self.generator_tab_button, PRIMARY, "white", PRIMARY_DARK)
                set_button_colors(self.settings_tab_button, CARD_ALT, TEXT, "#EEF2F7")

    def _build_generator_page(self):
            page = self.generator_page

            # Main workspace: left upload/preview, right batch review.
            workspace = tk.Frame(page, bg=BG, padx=18, pady=8)
            workspace.pack(fill="both", expand=True)
            workspace.grid_columnconfigure(0, weight=5, uniform="main")
            workspace.grid_columnconfigure(1, weight=6, uniform="main")
            workspace.grid_rowconfigure(0, weight=1)

            # LEFT — empty upload zone becomes selected-output preview after loading.
            self.upload_card = tk.Frame(workspace, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            self.upload_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
            self.upload_card.grid_rowconfigure(1, weight=1)
            self.upload_card.grid_columnconfigure(0, weight=1)

            left_header = tk.Frame(self.upload_card, bg=CARD, padx=14, pady=10)
            left_header.grid(row=0, column=0, sticky="ew")
            self.left_title = tk.Label(left_header, text="Add artwork batch", bg=CARD, fg=TEXT, font=("Segoe UI", 14, "bold"))
            self.left_title.pack(side="left")
            self.left_count = tk.Label(left_header, textvariable=self.batch_summary, bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold"))
            self.left_count.pack(side="right")

            self.preview_shell = tk.Frame(self.upload_card, bg=CHARCOAL, cursor="hand2")
            self.preview_shell.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 8))
            self.preview_shell.grid_rowconfigure(0, weight=1)
            self.preview_shell.grid_columnconfigure(0, weight=1)

            self.canvas = tk.Canvas(self.preview_shell, bg=CHARCOAL, highlightthickness=0)
            self.canvas.grid(row=0, column=0, sticky="nsew")
            self.canvas.bind("<Configure>", self.on_canvas_resize)
            self.canvas.bind("<Button-1>", lambda _e: self.load_zip(append=False) if not self.batch_items else None)

            # Empty upload prompt drawn as widgets above canvas.
            self.empty_upload_overlay = tk.Frame(self.preview_shell, bg=CHARCOAL, cursor="hand2")
            self.empty_upload_overlay.place(relx=0.5, rely=0.47, anchor="center")
            self.drop_plus_label = tk.Label(self.empty_upload_overlay, image=self.icons.get("plus_white"), bg=CHARCOAL, cursor="hand2")
            self.drop_plus_label.pack()
            self.drop_title = tk.Label(self.empty_upload_overlay, text="Drop batch ZIP here", bg=CHARCOAL, fg="white", font=("Segoe UI", 16, "bold"), cursor="hand2")
            self.drop_title.pack(pady=(8, 2))
            fallback_text = "or click to browse · maximum 250 artworks" if DND_AVAILABLE else "click to choose ZIP · maximum 250 artworks"
            self.drop_subtitle = tk.Label(self.empty_upload_overlay, text=fallback_text, bg=CHARCOAL, fg="#C9D4E3", font=("Segoe UI", 10), cursor="hand2")
            self.drop_subtitle.pack()
            for widget in (self.empty_upload_overlay, self.drop_plus_label, self.drop_title, self.drop_subtitle):
                widget.bind("<Button-1>", lambda _e: self.load_zip(append=bool(self.batch_items)))

            if DND_AVAILABLE and DND_FILES is not None:
                try:
                    self.preview_shell.drop_target_register(DND_FILES)
                    self.preview_shell.dnd_bind("<<DropEnter>>", lambda _e: self.set_drop_hover(True))
                    self.preview_shell.dnd_bind("<<DropLeave>>", lambda _e: self.set_drop_hover(False))
                    self.preview_shell.dnd_bind("<<Drop>>", self.on_drop_zip)
                except Exception:
                    pass

            # Thumbnail strip: sample artworks + final '+' tile to append another ZIP.
            self.sample_strip = tk.Frame(self.upload_card, bg=CARD, padx=12, pady=6)
            self.sample_strip.grid(row=2, column=0, sticky="ew")

            # RIGHT — modern large one-child-per-row review list.
            review_card = tk.Frame(workspace, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            review_card.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
            review_card.grid_rowconfigure(3, weight=1)
            review_card.grid_columnconfigure(0, weight=1)

            review_header = tk.Frame(review_card, bg=CARD, padx=14, pady=10)
            review_header.grid(row=0, column=0, sticky="ew")
            tk.Label(review_header, text="Batch Preview", bg=CARD, fg=TEXT, font=("Segoe UI", 15, "bold")).pack(side="left")
            self.search_nav_wrap = tk.Frame(review_header, bg=CARD)
            self.search_nav_wrap.pack(side="right")
            self.prev_result_button = make_button(self.search_nav_wrap, "", lambda: self.navigate_search(-1), icon=self.icons.get("left"), bg=CARD_ALT, fg=TEXT, active_bg="#EEF2F7", padx=6, pady=5)
            self.prev_result_button.pack(side="left")
            self.search_count_label = tk.Label(self.search_nav_wrap, text="0 / 0", bg=CARD, fg=MUTED, font=("Segoe UI", 10, "bold"), width=8)
            self.search_count_label.pack(side="left")
            self.next_result_button = make_button(self.search_nav_wrap, "", lambda: self.navigate_search(1), icon=self.icons.get("right"), bg=CARD_ALT, fg=TEXT, active_bg="#EEF2F7", padx=6, pady=5)
            self.next_result_button.pack(side="left")

            filter_row = tk.Frame(review_card, bg=CARD, padx=14, pady=5)
            filter_row.grid(row=1, column=0, sticky="ew")
            search_box = tk.Frame(filter_row, bg=CARD_ALT, highlightthickness=1, highlightbackground=BORDER)
            search_box.pack(side="left", fill="x", expand=True, padx=(0, 8))
            tk.Label(search_box, image=self.icons.get("search"), bg=CARD_ALT).pack(side="left", padx=(8, 4))
            self.search_entry = tk.Entry(search_box, textvariable=self.search_var, relief="flat", bd=0, bg=CARD_ALT, fg=TEXT, font=("Segoe UI", 11))
            self.search_entry.pack(side="left", fill="x", expand=True, ipady=8)
            self.search_entry.bind("<KeyRelease>", self.on_search_key)
            self.search_entry.bind("<Return>", lambda _e: self.apply_filters(select_first=True))
            self.search_clear_button = make_button(search_box, "", self.clear_search, icon=self.icons.get("close"), bg=CARD_ALT, fg=MUTED, active_bg="#E2E8F0", padx=5, pady=5, border_color=None)
            self.search_clear_button.pack(side="right", padx=4)

            self.type_combo = ttk.Combobox(filter_row, textvariable=self.type_filter, values=["All types", "Portrait", "Landscape"], state="readonly", width=12)
            self.type_combo.pack(side="left", padx=(0, 6), ipady=4)
            self.type_combo.bind("<<ComboboxSelected>>", lambda _e: self.apply_filters(select_first=True))

            self.status_filter_buttons = {}
            for status in ("All", "Ready", "Errors"):
                button = make_button(filter_row, status, lambda s=status: self.set_status_filter(s), bg=CARD_ALT, fg=TEXT, active_bg="#EEF2F7", padx=8, pady=6, font=("Segoe UI", 9, "bold"))
                button.pack(side="left", padx=2)
                self.status_filter_buttons[status] = button
            self.update_status_filter_styles()

            # Global template mode in the same compact toolbar.
            mode_row = tk.Frame(review_card, bg=CARD, padx=14, pady=4)
            mode_row.grid(row=2, column=0, sticky="ew")
            tk.Label(mode_row, text="Template", bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 8))
            self.batch_mode_buttons = {}
            for mode, icon_name in (("Auto", "auto"), ("Portrait", "portrait"), ("Landscape", "landscape")):
                button = make_button(mode_row, mode, lambda m=mode: self.set_batch_template_mode(m), icon=self.icons.get(icon_name), bg=CARD, fg=TEXT, active_bg=CARD_ALT, padx=9, pady=6, font=("Segoe UI", 9, "bold"))
                button.pack(side="left", padx=2)
                self.batch_mode_buttons[mode] = button
            self.update_batch_mode_styles()
            self.row_count_label = tk.Label(mode_row, text="", bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold"))
            self.row_count_label.pack(side="right")

            # Scrollable modern row list. Actual Edit/Delete are icon buttons, not text.
            rows_outer = tk.Frame(review_card, bg=CARD, padx=14, pady=5)
            rows_outer.grid(row=3, column=0, sticky="nsew")
            rows_outer.grid_rowconfigure(1, weight=1)
            rows_outer.grid_columnconfigure(0, weight=1)
            row_header = tk.Frame(rows_outer, bg="#EDF2F7", height=30)
            row_header.grid(row=0, column=0, sticky="ew", padx=(0, 0), pady=(0, 4))
            row_header.grid_propagate(False)
            for c, weight, minsize in ((0,0,64),(1,1,62),(2,2,120),(3,1,90),(4,1,95),(5,1,70),(6,0,34),(7,0,34)):
                row_header.grid_columnconfigure(c, weight=weight, minsize=minsize)
            headers = [(0,"Art"),(1,"ID"),(2,"Name"),(3,"Location"),(4,"Template"),(5,"Status")]
            for c, text in headers:
                tk.Label(row_header, text=text, bg="#EDF2F7", fg=MUTED, font=("Segoe UI", 9, "bold"), anchor="w").grid(row=0, column=c, sticky="ew", padx=5)
            self.rows_canvas = tk.Canvas(rows_outer, bg=CARD, highlightthickness=0)
            self.rows_scrollbar = ttk.Scrollbar(rows_outer, orient="vertical", command=self.rows_canvas.yview)
            self.rows_canvas.configure(yscrollcommand=self.rows_scrollbar.set)
            self.rows_canvas.grid(row=1, column=0, sticky="nsew")
            self.rows_scrollbar.grid(row=1, column=1, sticky="ns")
            self.rows_inner = tk.Frame(self.rows_canvas, bg=CARD)
            self.rows_window = self.rows_canvas.create_window((0, 0), window=self.rows_inner, anchor="nw")
            self.rows_inner.bind("<Configure>", lambda _e: self.rows_canvas.configure(scrollregion=self.rows_canvas.bbox("all")))
            self.rows_canvas.bind("<Configure>", lambda e: self.rows_canvas.itemconfigure(self.rows_window, width=e.width))
            self.rows_canvas.bind("<Enter>", lambda _e: self._bind_rows_mousewheel(True))
            self.rows_canvas.bind("<Leave>", lambda _e: self._bind_rows_mousewheel(False))

            # Bottom actions match the supplied wireframe: Clear left, green Download right.
            bottom = tk.Frame(page, bg=BG, padx=18, pady=5)
            bottom.pack(fill="x")
            self.clear_button = make_button(bottom, "Clear All", self.clear_all_images, icon=self.icons.get("clear_red"), bg=CARD, fg=DANGER, active_bg=DANGER_SOFT, font=("Segoe UI", 11, "bold"), padx=22, pady=10)
            self.clear_button.pack(side="left")
            self.generate_button = make_button(bottom, "Download All", self.generate_all, icon=self.icons.get("download_white"), bg=DOWNLOAD_GREEN, fg="white", active_bg=DOWNLOAD_GREEN_HOVER, border_color=None, font=("Segoe UI", 12, "bold"), padx=24, pady=11)
            self.generate_button.pack(side="right")
            self.cancel_button = make_button(bottom, "Cancel", self.cancel_generation, bg=CARD, fg=DANGER, active_bg=DANGER_SOFT, padx=12, pady=8, font=("Segoe UI", 9, "bold"))
            self.cancel_button.pack(side="right", padx=(0, 10))
            self.progress = ttk.Progressbar(bottom, variable=self.progress_value, maximum=100, length=260)
            self.progress.pack(side="right", padx=(0, 12))

            footer = tk.Frame(page, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            footer.pack(fill="x", side="bottom")
            tk.Label(footer, text="Creative technology @Rusala_Media", bg=CARD, fg=MUTED, font=("Segoe UI", 9), pady=5).pack()

            self.refresh_upload_samples()
            self.refresh_rows()

    def _bind_rows_mousewheel(self, active: bool):
            if active:
                self.bind_all("<MouseWheel>", self._on_rows_mousewheel)
            else:
                self.unbind_all("<MouseWheel>")

    def _on_rows_mousewheel(self, event):
            try:
                self.rows_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            except Exception:
                pass

    def on_search_key(self, _event=None):
            if self._search_job is not None:
                try:
                    self.after_cancel(self._search_job)
                except Exception:
                    pass
            self._search_job = self.after(120, lambda: self.apply_filters(select_first=True))

    def refresh_upload_samples(self):
            for child in self.sample_strip.winfo_children():
                child.destroy()
            self.upload_sample_photos.clear()
            if not self.batch_items:
                self.empty_upload_overlay.place(relx=0.5, rely=0.47, anchor="center")
                self.left_title.configure(text="Add artwork batch")
                return
            self.empty_upload_overlay.place_forget()
            self.left_title.configure(text="Selected output preview")
            # Show a compact sample strip; click a sample to preview it.
            max_samples = 6
            for index in range(min(len(self.batch_items), max_samples)):
                item = self.batch_items[index]
                frame = tk.Frame(self.sample_strip, bg=CARD_ALT, highlightthickness=1, highlightbackground=BORDER, cursor="hand2")
                frame.pack(side="left", padx=(0, 6))
                try:
                    image = ImageOps.exif_transpose(Image.open(item.source_path)).convert("RGB")
                    thumb = ImageOps.fit(image, (62, 46), Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(thumb)
                    self.upload_sample_photos.append(photo)
                    label = tk.Label(frame, image=photo, bg=CARD_ALT, cursor="hand2")
                    label.pack(padx=3, pady=3)
                    label.bind("<Button-1>", lambda _e, i=index: self.select_row_index(i, preview=True))
                    frame.bind("<Button-1>", lambda _e, i=index: self.select_row_index(i, preview=True))
                except Exception:
                    pass
            if len(self.batch_items) > max_samples:
                more = tk.Label(self.sample_strip, text=f"+{len(self.batch_items)-max_samples}", bg=PRIMARY_SOFT, fg=PRIMARY_DARK, font=("Segoe UI", 10, "bold"), padx=10, pady=14)
                more.pack(side="left", padx=(0, 6))
            add = make_button(self.sample_strip, "", lambda: self.load_zip(append=True), icon=self.icons.get("plus"), bg=CARD, fg=PRIMARY_DARK, active_bg=PRIMARY_SOFT, padx=12, pady=12)
            add.pack(side="left")
            tk.Label(self.sample_strip, text="Add more", bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=(5, 0))

    def _row_cell(self, parent, text: str, width: int, bold: bool = False, fg: str = TEXT, anchor="w"):
            label = tk.Label(parent, text=text, bg=parent.cget("bg"), fg=fg, font=("Segoe UI", 10, "bold" if bold else "normal"), anchor=anchor)
            label.configure(width=width)
            label.pack(side="left", padx=6)
            return label

    def refresh_rows(self):
            if not hasattr(self, "rows_inner"):
                return
            for child in self.rows_inner.winfo_children():
                child.destroy()
            self.row_frames.clear()
            self.row_editor_widgets = []
            query = self.search_var.get().strip().casefold()
            for visual_pos, index in enumerate(self.filtered_indices):
                item = self.batch_items[index]
                selected = index == self.preview_index
                bg = PRIMARY_SOFT if selected else (CARD if visual_pos % 2 == 0 else CARD_ALT)
                if item.status != "Ready":
                    bg = DANGER_SOFT
                elif query and (query in item.child_name.casefold() or query in item.submission_id.casefold()):
                    bg = "#FFF8DA" if not selected else PRIMARY_SOFT

                row = tk.Frame(self.rows_inner, bg=bg, height=68, highlightthickness=1, highlightbackground=PRIMARY if selected else BORDER, cursor="hand2")
                row.pack(fill="x", pady=(0, 6))
                row.pack_propagate(False)
                self.row_frames[index] = row
                for c, weight, minsize in ((0,0,64),(1,1,62),(2,2,120),(3,1,90),(4,1,95),(5,1,70),(6,0,34),(7,0,34)):
                    row.grid_columnconfigure(c, weight=weight, minsize=minsize)
                row.grid_rowconfigure(0, weight=1)

                thumb = self.create_thumbnail(item)
                thumb_label = tk.Label(row, image=thumb, bg=bg, cursor="hand2")
                thumb_label.grid(row=0, column=0, sticky="nsew", padx=5, pady=4)

                if self.editing_index == index:
                    id_entry = tk.Entry(row, textvariable=self.edit_id_var, font=("Segoe UI", 9), relief="solid", bd=1)
                    id_entry.grid(row=0, column=1, sticky="ew", padx=4, pady=13)
                    name_entry = tk.Entry(row, textvariable=self.edit_name_var, font=("Segoe UI", 10, "bold"), relief="solid", bd=1)
                    name_entry.grid(row=0, column=2, sticky="ew", padx=4, pady=13)
                    city_entry = tk.Entry(row, textvariable=self.edit_city_var, font=("Segoe UI", 9), relief="solid", bd=1)
                    city_entry.grid(row=0, column=3, sticky="ew", padx=4, pady=13)
                    mode_combo = ttk.Combobox(row, textvariable=self.edit_mode_var, values=["Auto", "Portrait", "Landscape"], state="readonly")
                    mode_combo.grid(row=0, column=4, sticky="ew", padx=4, pady=12)
                    status_text = "Ready" if item.status == "Ready" else "Error"
                    status_label = tk.Label(row, text=status_text, bg=bg, fg=SUCCESS if item.status == "Ready" else DANGER, font=("Segoe UI", 9, "bold"))
                    status_label.grid(row=0, column=5, sticky="ew", padx=3)
                    self.row_editor_widgets = [id_entry, name_entry, city_entry, mode_combo]
                    for widget in (id_entry, name_entry, city_entry):
                        widget.bind("<FocusOut>", self.schedule_commit_inline_edit)
                        widget.bind("<Return>", lambda _e: self.commit_inline_edit(close=True))
                        widget.bind("<Escape>", lambda _e: self.cancel_inline_edit())
                    mode_combo.bind("<<ComboboxSelected>>", lambda _e: self.commit_inline_edit(close=False))
                    id_entry.focus_set()
                else:
                    values = [
                        (1, item.submission_id or "—", MUTED, False),
                        (2, item.child_name, TEXT, True),
                        (3, item.city if item.city != "-" else "—", TEXT, False),
                    ]
                    for col, text, fg, bold in values:
                        lab = tk.Label(row, text=text, bg=bg, fg=fg, font=("Segoe UI", 10, "bold" if bold else "normal"), anchor="w")
                        lab.grid(row=0, column=col, sticky="ew", padx=5)
                    template_text = f"Auto→{item.selected_layout[:5]}" if item.template_mode == "Auto" else item.selected_layout
                    template_fg = PRIMARY_DARK if item.selected_layout == "Portrait" else ORANGE
                    template_label = tk.Label(row, text=template_text, bg=bg, fg=template_fg, font=("Segoe UI", 9, "bold"), anchor="center")
                    template_label.grid(row=0, column=4, sticky="ew", padx=3)
                    status_text = "Ready" if item.status == "Ready" else "Error"
                    status_label = tk.Label(row, text=status_text, bg=bg, fg=SUCCESS if item.status == "Ready" else DANGER, font=("Segoe UI", 9, "bold"), anchor="center")
                    status_label.grid(row=0, column=5, sticky="ew", padx=3)

                edit_btn = make_button(row, "", lambda i=index: self.open_inline_edit(i), icon=self.icons.get("edit_user"), bg=bg, fg=TEXT, active_bg="#E8EEF6", padx=3, pady=3, border_color=None)
                edit_btn.grid(row=0, column=6, padx=1, pady=15)
                delete_btn = make_button(row, "", lambda i=index: self.delete_batch_item(i), icon=self.icons.get("delete_user"), bg=bg, fg=DANGER, active_bg=DANGER_SOFT, padx=3, pady=3, border_color=None)
                delete_btn.grid(row=0, column=7, padx=(1,4), pady=15)

                for widget in row.winfo_children():
                    if widget not in (edit_btn, delete_btn) and not isinstance(widget, (tk.Entry, ttk.Combobox)):
                        widget.bind("<Button-1>", lambda _e, i=index: self.select_row_index(i, preview=True))
                row.bind("<Button-1>", lambda _e, i=index: self.select_row_index(i, preview=True))

            self.row_count_label.configure(text=f"Showing {len(self.filtered_indices)} of {len(self.batch_items)}")
            self.rows_canvas.configure(scrollregion=self.rows_canvas.bbox("all"))

    def select_row_index(self, index: int, preview: bool = False):
            if not self.batch_items:
                return
            index = max(0, min(index, len(self.batch_items) - 1))
            if self.editing_index is not None and self.editing_index != index:
                self.commit_inline_edit(close=True)
            self.preview_index = index
            self.refresh_rows()
            if preview:
                self.after_idle(self.preview_selected)
            self.after_idle(lambda i=index: self.scroll_row_into_view(i))

    def scroll_row_into_view(self, index: int):
            frame = self.row_frames.get(index)
            if frame is None:
                return
            self.update_idletasks()
            total_h = max(self.rows_inner.winfo_height(), 1)
            view_h = max(self.rows_canvas.winfo_height(), 1)
            y = frame.winfo_y()
            current_top = self.rows_canvas.canvasy(0)
            current_bottom = current_top + view_h
            if y < current_top or y + frame.winfo_height() > current_bottom:
                self.rows_canvas.yview_moveto(max(0.0, min(1.0, y / total_h)))

    def _inline_field(self, parent, label: str, variable: tk.StringVar, column: int):
            tk.Label(parent, text=label, bg="#F8FBFF", fg=MUTED, font=("Segoe UI", 9, "bold")).grid(row=0, column=column, sticky="w", padx=(0, 6))
            entry = tk.Entry(parent, textvariable=variable, bg=CARD, fg=TEXT, relief="solid", bd=1, font=("Segoe UI", 10))
            entry.grid(row=0, column=column + 1, sticky="ew", padx=(0, 12), ipady=6)
            entry.bind("<FocusOut>", self.schedule_commit_inline_edit)
            entry.bind("<Return>", lambda _e: self.commit_inline_edit())
            entry.bind("<Escape>", lambda _e: self.cancel_inline_edit())

    def _stat_chip(self, parent, variable: tk.StringVar, bg: str, fg: str):
            label = tk.Label(parent, textvariable=variable, bg=bg, fg=fg, font=("Segoe UI", 9, "bold"), padx=10, pady=5)
            label.pack(side="left", padx=(0, 7))

    def set_drop_hover(self, hover: bool):
            color = CHARCOAL_HOVER if hover else CHARCOAL
            if hasattr(self, "preview_shell"):
                self.preview_shell.configure(bg=color, highlightbackground=PRIMARY if hover else color)
                self.canvas.configure(bg=color)
                if hasattr(self, "empty_upload_overlay"):
                    self.empty_upload_overlay.configure(bg=color)
                    for child in self.empty_upload_overlay.winfo_children():
                        child.configure(bg=color)

    def on_canvas_resize(self, _event=None):
            if self.batch_items:
                self.after_idle(self.preview_selected)
