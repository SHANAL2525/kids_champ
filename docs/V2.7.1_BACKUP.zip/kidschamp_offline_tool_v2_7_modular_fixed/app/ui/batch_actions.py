import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class BatchActionsMixin:
    def on_drop_zip(self, event):
            self.set_drop_hover(False)
            try:
                paths = self.tk.splitlist(event.data)
            except Exception:
                paths = [str(event.data)]
            if not paths:
                return
            path = str(paths[0]).strip("{}")
            if Path(path).suffix.lower() != ".zip":
                messagebox.showwarning("ZIP required", "Drop one Kids Champ ZIP file.")
                return
            self.load_zip(path, append=bool(self.batch_items))

    def set_status(self, text: str):
            self.status_text.set(text)

    def get_template_signature(self):
            signature = []
            for path in sorted(TEMPLATE_DIR.glob("*")):
                if path.suffix.lower() in {".json", ".png", ".jpg", ".jpeg"}:
                    try:
                        signature.append((path.name, path.stat().st_mtime_ns, path.stat().st_size))
                    except OSError:
                        continue
            return tuple(signature)

    def on_app_focus(self, _event=None):
            if self.is_generating:
                return
            current = self.get_template_signature()
            if current != self.template_signature:
                self.reload_templates(silent=True)
                self.template_signature = current
                self.set_status("Template changes loaded automatically.")

    def reload_templates(self, silent: bool = False):
            template_store.reload_template_cache()
            self.template_signature = self.get_template_signature()
            if self.batch_items:
                self.preview_selected()
            if not silent:
                messagebox.showinfo(
                    "Templates loaded",
                    f"Loaded {len(template_store.TEMPLATE_LAYOUTS)} saved templates.",
                )

    def update_button_states(self):
            has_batch = bool(self.batch_items)
            busy = self.is_generating
            self.generate_button.configure(state="normal" if has_batch and not busy else "disabled")
            self.clear_button.configure(state="normal" if (has_batch or self.generated_paths) and not busy else "disabled")
            self.cancel_button.configure(state="normal" if busy else "disabled")
            for button in self.batch_mode_buttons.values():
                button.configure(state="normal" if has_batch and not busy else "disabled")

    def update_stats(self):
            total = len(self.batch_items)
            ready = sum(item.status == "Ready" for item in self.batch_items)
            errors = total - ready
            portrait = sum(item.status == "Ready" and item.selected_layout == "Portrait" for item in self.batch_items)
            landscape = sum(item.status == "Ready" and item.selected_layout == "Landscape" for item in self.batch_items)
            self.total_stat.set(f"{total} / {MAX_BATCH_IMAGES} artworks")
            self.ready_stat.set(f"{ready} ready")
            self.error_stat.set(f"{errors} errors")
            self.layout_stat.set(f"{portrait} portrait · {landscape} landscape")

    def cleanup_temp(self):
            if self.temp_dir and os.path.isdir(self.temp_dir):
                shutil.rmtree(self.temp_dir, ignore_errors=True)
            self.temp_dir = None
            self.loaded_zip_path = None
            self.loaded_zip_paths = []

    def reset_batch_ui(self):
            self.batch_items = []
            self.filtered_indices = []
            self.search_match_indices = []
            self.search_result_position = -1
            self.preview_index = 0
            self.preview_photo = None
            self.thumbnail_cache.clear()
            self.canvas.delete("all")
            self.editing_index = None
            self.edit_original = None
            self.batch_summary.set("No batch selected")
            self.search_var.set("")
            self.search_count_label.configure(text="0 / 0")
            self.progress_value.set(0)
            self.loaded_zip_paths = []
            self.loaded_zip_path = None
            self.refresh_upload_samples()
            self.refresh_rows()
            self.update_stats()
            self.update_button_states()

    def load_zip(self, path: Optional[str] = None, append: bool = False):
            if path is None:
                path = filedialog.askopenfilename(title="Choose Kids Champ ZIP", filetypes=[("ZIP files", "*.zip")])
            if not path:
                return
            if not append and self.batch_items:
                if not messagebox.askyesno("Replace current batch", "Replace the currently loaded batch?\n\nSaved templates will not be changed."):
                    return
            if not append:
                self.cleanup_temp()
                self.reset_batch_ui()
            if self.temp_dir is None:
                self.temp_dir = tempfile.mkdtemp(prefix="kidschamp_v2_7_")
            existing_count = len(self.batch_items)
            seen_ids = {item.submission_id.casefold() for item in self.batch_items if item.submission_id}
            items: List[BatchItem] = []
            try:
                with zipfile.ZipFile(path, "r") as archive:
                    image_members = [
                        member for member in archive.infolist()
                        if not member.is_dir()
                        and not Path(member.filename).name.startswith("._")
                        and Path(member.filename).suffix.lower() in SUPPORTED_EXTENSIONS
                    ]
                    if not image_members:
                        raise ValueError("No supported artwork images were found inside this ZIP.")
                    if existing_count + len(image_members) > MAX_BATCH_IMAGES:
                        raise ValueError(f"This would make {existing_count + len(image_members)} artworks. The maximum is {MAX_BATCH_IMAGES}.")
                    total_members = len(image_members)
                    for local_index, member in enumerate(image_members, start=1):
                        global_index = existing_count + local_index
                        self.set_status(f"Reading artwork {global_index}/{existing_count + total_members}...")
                        self.progress_value.set(local_index / max(total_members, 1) * 100)
                        self.update_idletasks()
                        original_name = Path(member.filename).name
                        suffix = Path(original_name).suffix.lower() or ".img"
                        destination = Path(self.temp_dir) / f"{uuid.uuid4().hex}{suffix}"
                        with archive.open(member) as source, open(destination, "wb") as target:
                            shutil.copyfileobj(source, target)
                        try:
                            with Image.open(destination) as test_image:
                                test_image.verify()
                            submission_id, child_name, city, parse_format = parse_filename(original_name)
                            detected = detect_layout(str(destination))
                            status, warning = "Ready", ""
                            if submission_id:
                                normalized_id = submission_id.casefold()
                                if normalized_id in seen_ids:
                                    status, warning = "Error", "Duplicate ID"
                                seen_ids.add(normalized_id)
                        except Exception as exc:
                            submission_id, child_name, city, parse_format = "", "-", "-", "-"
                            detected, status, warning = "Landscape", "Error", str(exc)
                        items.append(BatchItem(str(destination), original_name, submission_id, child_name, city, detected, detected, "Auto", parse_format, status, warning))
            except zipfile.BadZipFile:
                messagebox.showerror("ZIP error", "This is not a valid ZIP file.")
                if not append:
                    self.cleanup_temp(); self.reset_batch_ui()
                return
            except Exception as exc:
                messagebox.showerror("ZIP error", str(exc))
                if not append:
                    self.cleanup_temp(); self.reset_batch_ui()
                return

            self.batch_items.extend(items)
            self.loaded_zip_paths.append(Path(path))
            self.loaded_zip_path = self.loaded_zip_paths[0] if self.loaded_zip_paths else None
            self.batch_template_mode = "Auto"
            self.update_batch_mode_styles()
            zip_count = len(self.loaded_zip_paths)
            self.batch_summary.set(f"{len(self.batch_items)} artworks · {zip_count} ZIP{'s' if zip_count != 1 else ''}")
            self.update_stats()
            self.apply_filters(select_first=not append)
            self.progress_value.set(0)
            ready = sum(item.status == "Ready" for item in self.batch_items)
            errors = len(self.batch_items) - ready
            self.refresh_upload_samples()
            if append and items:
                self.select_row_index(existing_count, preview=True)
            self.set_status(f"Loaded {len(self.batch_items)} artworks: {ready} ready, {errors} errors.")
            self.update_button_states()

    def create_thumbnail(self, item: BatchItem) -> Optional[ImageTk.PhotoImage]:
            if item.source_path in self.thumbnail_cache:
                return self.thumbnail_cache[item.source_path]
            try:
                image = ImageOps.exif_transpose(Image.open(item.source_path)).convert("RGB")
                canvas = Image.new("RGB", (56, 56), "white")
                contained = ImageOps.contain(image, (54, 54), Image.Resampling.LANCZOS)
                canvas.paste(contained, ((56 - contained.width) // 2, (56 - contained.height) // 2))
                photo = ImageTk.PhotoImage(canvas)
                self.thumbnail_cache[item.source_path] = photo
                return photo
            except Exception:
                return None

    def apply_filters(self, select_first: bool = False):
            query = self.search_var.get().strip().casefold()
            type_filter = self.type_filter.get()
            indices: List[int] = []
            search_matches: List[int] = []
            for index, item in enumerate(self.batch_items):
                status_ok = self.status_filter == "All" or (self.status_filter == "Ready" and item.status == "Ready") or (self.status_filter == "Errors" and item.status != "Ready")
                type_ok = type_filter == "All types" or item.selected_layout == type_filter
                query_ok = not query or query in item.child_name.casefold() or query in item.submission_id.casefold()
                if query_ok:
                    search_matches.append(index)
                if status_ok and type_ok and query_ok:
                    indices.append(index)
            self.filtered_indices = indices
            self.search_match_indices = [index for index in search_matches if index in indices]
            if query and self.search_match_indices:
                if select_first or self.search_result_position < 0 or self.search_result_position >= len(self.search_match_indices):
                    self.search_result_position = 0
                self.preview_index = self.search_match_indices[self.search_result_position]
            elif indices and select_first:
                self.search_result_position = -1
                self.preview_index = indices[0]
            self.refresh_rows()
            if self.batch_items:
                self.preview_selected()
            self.update_search_nav()

    def update_search_nav(self):
            total = len(self.search_match_indices) if self.search_var.get().strip() else 0
            if total:
                position = max(0, self.search_result_position) + 1
                self.search_count_label.configure(text=f"{position} / {total}")
                state = "normal"
            else:
                self.search_count_label.configure(text="0 / 0")
                state = "disabled"
            self.prev_result_button.configure(state=state)
            self.next_result_button.configure(state=state)

    def navigate_search(self, direction: int):
            if not self.search_match_indices:
                return
            self.search_result_position = (self.search_result_position + direction) % len(self.search_match_indices)
            index = self.search_match_indices[self.search_result_position]
            self.select_row_index(index, preview=True)
            self.update_search_nav()

    def clear_search(self):
            self.search_var.set("")
            self.search_result_position = -1
            self.apply_filters(select_first=True)
            self.search_entry.focus_set()

    def set_status_filter(self, status: str):
            self.status_filter = status
            self.update_status_filter_styles()
            self.apply_filters(select_first=True)

    def update_status_filter_styles(self):
            for status, button in self.status_filter_buttons.items():
                if status == self.status_filter:
                    set_button_colors(button, PRIMARY, "white", PRIMARY_DARK)
                else:
                    set_button_colors(button, CARD_ALT, TEXT, "#EEF2F7")

    def set_batch_template_mode(self, mode: str):
            if not self.batch_items:
                return
            self.batch_template_mode = mode
            for item in self.batch_items:
                item.template_mode = mode
                item.selected_layout = item.detected_layout if mode == "Auto" else mode
            self.update_batch_mode_styles()
            self.update_stats()
            self.apply_filters(select_first=False)
            self.preview_selected()
            self.set_status(f"Applied {mode} template mode to all {len(self.batch_items)} artworks.")

    def update_batch_mode_styles(self):
            colors = {"Auto": PRIMARY, "Portrait": PURPLE, "Landscape": ORANGE}
            icons = {"Auto": "auto", "Portrait": "portrait", "Landscape": "landscape"}
            for mode, button in self.batch_mode_buttons.items():
                if mode == self.batch_template_mode:
                    button.configure(image=self.icons.get(icons[mode] + "_white"))
                    set_button_colors(button, colors[mode], "white", colors[mode])
                else:
                    button.configure(image=self.icons.get(icons[mode]))
                    set_button_colors(button, CARD, TEXT, CARD_ALT)

    def update_edit_mode_styles(self):
            colors = {"Auto": PRIMARY, "Portrait": PURPLE, "Landscape": ORANGE}
            icons = {"Auto": "auto", "Portrait": "portrait", "Landscape": "landscape"}
            selected = self.edit_mode_var.get()
            for mode, button in self.edit_mode_buttons.items():
                if mode == selected:
                    button.configure(image=self.icons.get(icons[mode] + "_white"))
                    set_button_colors(button, colors[mode], "white", colors[mode])
                else:
                    button.configure(image=self.icons.get(icons[mode]))
                    set_button_colors(button, CARD, TEXT, CARD_ALT)

    def on_tree_click(self, event):
            # Kept for backward compatibility; V2.7 uses real row widgets.
            return None

    def on_tree_select(self, _event=None):
            return None

    def select_tree_index(self, index: int, preview: bool = False):
            self.select_row_index(index, preview=preview)
