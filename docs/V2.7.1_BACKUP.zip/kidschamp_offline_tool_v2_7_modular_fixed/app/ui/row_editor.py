import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class RowEditorMixin:
    def open_inline_edit(self, index: int):
            if index < 0 or index >= len(self.batch_items):
                return
            if self.editing_index == index:
                self.commit_inline_edit(close=True)
                return
            if self.editing_index is not None:
                self.commit_inline_edit(close=True)
            self.editing_index = index
            item = self.batch_items[index]
            self.edit_original = (item.submission_id, item.child_name, item.city, item.template_mode)
            self.edit_id_var.set(item.submission_id)
            self.edit_name_var.set(item.child_name if item.child_name != "-" else "")
            self.edit_city_var.set(item.city if item.city != "-" else "")
            self.edit_mode_var.set(item.template_mode)
            self.preview_index = index
            self.refresh_rows()
            self.preview_selected()
            self.scroll_row_into_view(index)
            self.set_status("Edit ID, name or location directly in the row. Click outside to save automatically.")

    def close_inline_edit(self):
            if self.editing_index is not None:
                self.commit_inline_edit(close=True)

    def cancel_inline_edit(self):
            if self.editing_index is not None and self.edit_original is not None:
                item = self.batch_items[self.editing_index]
                item.submission_id, item.child_name, item.city, item.template_mode = self.edit_original
                item.selected_layout = item.detected_layout if item.template_mode == "Auto" else item.template_mode
            self.editing_index = None
            self.edit_original = None
            self.refresh_rows()
            self.preview_selected()

    def schedule_commit_inline_edit(self, _event=None):
            if self._edit_save_job is not None:
                try:
                    self.after_cancel(self._edit_save_job)
                except Exception:
                    pass
            self._edit_save_job = self.after(180, self._commit_if_editor_lost_focus)

    def _commit_if_editor_lost_focus(self):
            self._edit_save_job = None
            focus = self.focus_get()
            if focus in self.row_editor_widgets:
                return
            self.commit_inline_edit(close=True)

    def commit_inline_edit(self, close: bool = False):
            if self.editing_index is None or self.editing_index >= len(self.batch_items):
                return
            if self._edit_save_job is not None:
                try:
                    self.after_cancel(self._edit_save_job)
                except Exception:
                    pass
                self._edit_save_job = None
            index = self.editing_index
            item = self.batch_items[index]
            name = self.edit_name_var.get().strip()
            city = self.edit_city_var.get().strip()
            item.submission_id = self.edit_id_var.get().strip()
            item.child_name = name or "-"
            item.city = city or "-"
            item.template_mode = self.edit_mode_var.get()
            item.selected_layout = item.detected_layout if item.template_mode == "Auto" else item.template_mode
            item.parse_format = "Manual edit"
            item.status = "Ready" if name and city else "Error"
            item.warning = "" if item.status == "Ready" else "Name or location is missing"
            self.revalidate_duplicate_ids()
            self.update_stats()
            if close:
                self.editing_index = None
                self.edit_original = None
            self.apply_filters(select_first=False)
            self.preview_index = min(index, max(0, len(self.batch_items)-1))
            self.refresh_upload_samples()
            self.preview_selected()
            self.set_status(f"Updated: {item.child_name} · {item.city}")

    def set_edit_mode(self, mode: str):
            self.edit_mode_var.set(mode)
            self.commit_inline_edit(close=False)

    def revalidate_duplicate_ids(self):
            counts: Dict[str, int] = {}
            for item in self.batch_items:
                if item.submission_id:
                    key = item.submission_id.casefold()
                    counts[key] = counts.get(key, 0) + 1
            for item in self.batch_items:
                if item.child_name in {"", "-"} or item.city in {"", "-"}:
                    item.status = "Error"
                    item.warning = "Name or location is missing"
                elif item.submission_id and counts.get(item.submission_id.casefold(), 0) > 1:
                    item.status = "Error"
                    item.warning = "Duplicate ID"
                else:
                    item.status = "Ready"
                    item.warning = ""

    def delete_batch_item(self, index: int):
            if index < 0 or index >= len(self.batch_items):
                return
            item = self.batch_items[index]
            try:
                Path(item.source_path).unlink(missing_ok=True)
            except OSError:
                pass
            del self.batch_items[index]
            self.editing_index = None
            self.edit_original = None
            self.revalidate_duplicate_ids()
            self.preview_index = min(index, max(0, len(self.batch_items) - 1))
            self.update_stats()
            self.apply_filters(select_first=False)
            self.refresh_upload_samples()
            if self.batch_items:
                self.select_row_index(self.preview_index, preview=True)
            else:
                self.reset_batch_ui()
            self.set_status(f"Removed artwork: {item.child_name}")
