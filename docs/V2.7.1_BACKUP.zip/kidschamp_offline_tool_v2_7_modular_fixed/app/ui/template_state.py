import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class TemplateStateMixin:
    def capture_state(self) -> dict:
            return {
                "current_json_path": str(self.current_json_path) if self.current_json_path else None,
                "template_image_path": str(self.template_image_path) if self.template_image_path else None,
                "original_image": self.original_image.copy() if self.original_image is not None else None,
                "boxes": {key: list(value) for key, value in self.boxes.items()},
                "template_name": self.template_name.get(),
                "template_type": self.template_type.get(),
                "artwork_fit_mode": self.artwork_fit_mode.get(),
                "name_font_size": int(self.name_font_size.get()),
                "city_font_size": int(self.city_font_size.get()),
                "text_color": self.text_color.get(),
                "show_location_pin": bool(self.show_location_pin.get()),
                "location_pin_size": int(self.location_pin_size.get()),
                "location_pin_gap": int(self.location_pin_gap.get()),
                "sample_name": self.sample_name.get(),
                "sample_city": self.sample_city.get(),
            }

    def restore_state(self, state: dict):
            self.current_json_path = Path(state["current_json_path"]) if state.get("current_json_path") else None
            self.template_image_path = Path(state["template_image_path"]) if state.get("template_image_path") else None
            image = state.get("original_image")
            self.original_image = image.copy() if image is not None else None
            self.boxes = {key: list(value) for key, value in state["boxes"].items()}
            self.template_name.set(state["template_name"])
            self.template_type.set(state["template_type"])
            self.artwork_fit_mode.set(state.get("artwork_fit_mode", "Fill Frame"))
            self.name_font_size.set(state["name_font_size"])
            self.city_font_size.set(state["city_font_size"])
            self.text_color.set(state["text_color"])
            self.show_location_pin.set(state["show_location_pin"])
            self.location_pin_size.set(state["location_pin_size"])
            self.location_pin_gap.set(state["location_pin_gap"])
            self.sample_name.set(state["sample_name"])
            self.sample_city.set(state["sample_city"])
            self.mark_dirty()
            self.redraw()

    def push_undo_once(self, _event=None):
            if not self.undo_stack or self.undo_stack[-1].get("template_name") != self.template_name.get():
                self.push_undo()

    def push_undo(self):
            self.undo_stack.append(self.capture_state())
            if len(self.undo_stack) > 30:
                self.undo_stack.pop(0)
            self.undo_button.configure(state="normal")

    def undo(self):
            if not self.undo_stack:
                self.app.set_status("Nothing to undo in Template Settings.")
                return
            state = self.undo_stack.pop()
            self.restore_state(state)
            self.undo_button.configure(state="normal" if self.undo_stack else "disabled")
            self.app.set_status("Template change undone.")

    def mark_dirty(self):
            self.dirty = True
            self.unsaved_text.set("Unsaved changes")
            self.unsaved_label.configure(bg=WARNING_SOFT, fg=WARNING)
            self.preview_mode = "current"
            self.update_preview_toggle_styles()

    def mark_saved(self):
            self.dirty = False
            self.unsaved_text.set("Saved")
            self.unsaved_label.configure(bg=SUCCESS_SOFT, fg=SUCCESS)

    def on_property_change(self, _event=None):
            if self.properties_editing:
                self.mark_dirty()
                self.redraw()
