import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

from .template_settings import TemplateSettingsPanel
from .generator_layout import GeneratorLayoutMixin
from .batch_actions import BatchActionsMixin
from .row_editor import RowEditorMixin
from .output_actions import OutputActionsMixin

class KidsChampApp(
    GeneratorLayoutMixin,
    BatchActionsMixin,
    RowEditorMixin,
    OutputActionsMixin,
    ROOT_CLASS,
):
    def __init__(self):
            super().__init__()
            self.title(APP_TITLE)
            self.geometry("1500x920")
            self.minsize(1180, 760)
            self.configure(bg=BG)

            self.icons: Dict[str, Optional[ImageTk.PhotoImage]] = {}
            for name in (
                "plus", "plus_white", "upload", "download_white", "search", "edit", "trash_red", "settings",
                "folder", "undo", "save_white", "clear_red", "generator", "template", "left", "right", "lock",
                "portrait", "landscape", "auto", "generator_white", "settings_white", "portrait_white", "landscape_white", "auto_white", "imageic", "close", "edit_user", "delete_user",
            ):
                self.icons[name] = load_icon(name, 20)

            self.batch_items: List[BatchItem] = []
            self.temp_dir: Optional[str] = None
            self.loaded_zip_path: Optional[Path] = None
            self.loaded_zip_paths: List[Path] = []
            self.preview_index = 0
            self.preview_photo = None
            self.thumbnail_cache: Dict[str, ImageTk.PhotoImage] = {}
            self.filtered_indices: List[int] = []
            self.search_match_indices: List[int] = []
            self.search_result_position = -1
            self.generated_paths: List[Path] = []
            self.last_output_folder: Optional[Path] = None
            self.last_output_zip: Optional[Path] = None
            self.status_text = tk.StringVar(value="Drop a Kids Champ ZIP file or click the upload area. No unzip is needed.")
            self.progress_value = tk.DoubleVar(value=0)
            self.total_stat = tk.StringVar(value="0 artworks")
            self.ready_stat = tk.StringVar(value="0 ready")
            self.error_stat = tk.StringVar(value="0 errors")
            self.layout_stat = tk.StringVar(value="0 portrait · 0 landscape")
            self.batch_summary = tk.StringVar(value="No batch selected")
            self.search_var = tk.StringVar(value="")
            self.type_filter = tk.StringVar(value="All types")
            self.status_filter = "All"
            self.batch_template_mode = "Auto"
            self.is_generating = False
            self.generation_queue = queue.Queue()
            self.cancel_generation_event = threading.Event()
            self.template_signature = self.get_template_signature()
            self.editing_index: Optional[int] = None
            self.edit_original: Optional[Tuple[str, str, str, str]] = None
            self.edit_id_var = tk.StringVar()
            self.edit_name_var = tk.StringVar()
            self.edit_city_var = tk.StringVar()
            self.edit_mode_var = tk.StringVar(value="Auto")
            self._edit_save_job = None
            self.row_frames: Dict[int, tk.Frame] = {}
            self.row_editor_widgets: List[tk.Widget] = []
            self.upload_sample_photos: List[ImageTk.PhotoImage] = []
            self._search_job = None

            self._configure_styles()
            self._build_ui()
            self.update_button_states()
            self.protocol("WM_DELETE_WINDOW", self.on_close)
            self.bind("<FocusIn>", self.on_app_focus)
