import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class TemplateCanvasMixin:
    def view_state(self) -> dict:
            if self.preview_mode == "saved" and self.saved_state is not None:
                return self.saved_state
            return self.capture_state()

    def image_to_canvas(self, x: float, y: float) -> Tuple[float, float]:
            return self.offset_x + x * self.scale, self.offset_y + y * self.scale

    def canvas_to_image(self, x: float, y: float) -> Tuple[float, float]:
            return (x - self.offset_x) / max(self.scale, 0.0001), (y - self.offset_y) / max(self.scale, 0.0001)

    def redraw(self):
            self.canvas.delete("all")
            state = self.view_state()
            image = state.get("original_image")
            if image is None:
                width = max(self.canvas.winfo_width(), 400)
                height = max(self.canvas.winfo_height(), 300)
                self.canvas.create_text(
                    width / 2,
                    height / 2,
                    text="Upload a template image to start",
                    fill="#D8E0EA",
                    font=("Segoe UI", 15, "bold"),
                )
                return
            cw = max(self.canvas.winfo_width(), 300)
            ch = max(self.canvas.winfo_height(), 300)
            iw, ih = image.size
            self.scale = min((cw - 36) / iw, (ch - 36) / ih)
            self.scale = max(self.scale, 0.03)
            dw = max(1, int(iw * self.scale))
            dh = max(1, int(ih * self.scale))
            self.offset_x = (cw - dw) / 2
            self.offset_y = (ch - dh) / 2
            display = image.resize((dw, dh), Image.Resampling.LANCZOS)
            self.photo = ImageTk.PhotoImage(display)
            self.canvas.create_image(self.offset_x, self.offset_y, image=self.photo, anchor="nw")

            boxes = state["boxes"]
            selected_key = self.selected_box.get()
            for key, box in boxes.items():
                x, y, w, h = box
                x1, y1 = self.image_to_canvas(x, y)
                x2, y2 = self.image_to_canvas(x + w, y + h)
                color = self.BOX_COLORS[key]
                width = 4 if key == selected_key and self.preview_mode == "current" else 2
                self.canvas.create_rectangle(x1, y1, x2, y2, outline=color, width=width)
                self.canvas.create_text(x1 + 6, y1 + 6, anchor="nw", text=self.BOX_LABELS[key], fill=color, font=("Segoe UI", 10, "bold"))
                if key == selected_key and self.preview_mode == "current" and self.properties_editing:
                    handle = 7
                    self.canvas.create_rectangle(x2 - handle, y2 - handle, x2 + handle, y2 + handle, fill=color, outline="white")

            self.draw_sample_text(state)
            current_box = boxes[selected_key]
            self.box_values.set(
                f"x: {current_box[0]}   y: {current_box[1]}\nwidth: {current_box[2]}   height: {current_box[3]}"
            )

    def draw_canvas_pin(self, x: float, y: float, size: int):
            size = max(8, size)
            center_x = x + size * 0.50
            circle_center_y = y + size * 0.35
            outer_r = size * 0.28
            self.canvas.create_polygon(
                center_x - outer_r * 0.70,
                circle_center_y + outer_r * 0.55,
                center_x + outer_r * 0.70,
                circle_center_y + outer_r * 0.55,
                center_x,
                y + size * 0.96,
                fill="#D92D20",
                outline="",
            )
            self.canvas.create_oval(
                center_x - outer_r,
                circle_center_y - outer_r,
                center_x + outer_r,
                circle_center_y + outer_r,
                fill="#FF3B30",
                outline="",
            )
            inner_r = outer_r * 0.38
            self.canvas.create_oval(
                center_x - inner_r,
                circle_center_y - inner_r,
                center_x + inner_r,
                circle_center_y + inner_r,
                fill="#FFFFFF",
                outline="",
            )

    def draw_sample_text(self, state: dict):
            boxes = state["boxes"]
            x, y, w, h = boxes["name_box"]
            cx, cy = self.image_to_canvas(x + w / 2, y + h / 2)
            name_size = max(8, int(state["name_font_size"] * self.scale))
            self.canvas.create_text(
                cx,
                cy,
                text=state["sample_name"].upper(),
                fill=state["text_color"],
                font=("Arial", name_size, "bold"),
                anchor="center",
            )
            x, y, w, h = boxes["city_box"]
            cx, cy = self.image_to_canvas(x + w / 2, y + h / 2)
            city_text = state["sample_city"].upper()
            city_size = max(8, int(state["city_font_size"] * self.scale))
            if not state["show_location_pin"]:
                self.canvas.create_text(cx, cy, text=city_text, fill=state["text_color"], font=("Arial", city_size, "bold"), anchor="center")
                return
            temp_id = self.canvas.create_text(0, 0, text=city_text, font=("Arial", city_size, "bold"), anchor="nw")
            bbox = self.canvas.bbox(temp_id) or (0, 0, 1, city_size)
            self.canvas.delete(temp_id)
            text_width = bbox[2] - bbox[0]
            pin_size = max(8, int(state["location_pin_size"] * self.scale))
            gap = max(0, int(state["location_pin_gap"] * self.scale))
            total_width = pin_size + gap + text_width
            group_left = cx - total_width / 2
            pin_top = cy - pin_size / 2
            self.draw_canvas_pin(group_left, pin_top, pin_size)
            self.canvas.create_text(
                group_left + pin_size + gap,
                cy,
                text=city_text,
                fill=state["text_color"],
                font=("Arial", city_size, "bold"),
                anchor="w",
            )

    def hit_test(self, canvas_x: float, canvas_y: float) -> str:
            key = self.selected_box.get()
            x, y, w, h = self.boxes[key]
            x1, y1 = self.image_to_canvas(x, y)
            x2, y2 = self.image_to_canvas(x + w, y + h)
            if abs(canvas_x - x2) <= 14 and abs(canvas_y - y2) <= 14:
                return "resize"
            if x1 <= canvas_x <= x2 and y1 <= canvas_y <= y2:
                return "move"
            return "draw"

    def on_mouse_down(self, event):
            if self.preview_mode != "current" or not self.properties_editing or self.original_image is None:
                return
            self.canvas.focus_set()
            self.push_undo()
            self.drag_mode = self.hit_test(event.x, event.y)
            self.drag_start = self.canvas_to_image(event.x, event.y)
            self.drag_original = list(self.boxes[self.selected_box.get()])
            if self.drag_mode == "draw":
                ix, iy = self.drag_start
                self.boxes[self.selected_box.get()] = [int(ix), int(iy), 1, 1]

    def on_mouse_move(self, event):
            if not self.drag_mode or not self.drag_start or not self.drag_original:
                return
            key = self.selected_box.get()
            ix, iy = self.canvas_to_image(event.x, event.y)
            sx, sy = self.drag_start
            ox, oy, ow, oh = self.drag_original
            if self.drag_mode == "move":
                self.boxes[key] = [int(ox + ix - sx), int(oy + iy - sy), ow, oh]
            elif self.drag_mode == "resize":
                self.boxes[key] = [ox, oy, max(10, int(ow + ix - sx)), max(10, int(oh + iy - sy))]
            else:
                x1, y1 = sx, sy
                x2, y2 = ix, iy
                self.boxes[key] = [int(min(x1, x2)), int(min(y1, y2)), max(10, int(abs(x2 - x1))), max(10, int(abs(y2 - y1)))]
            self.clamp_box(key)
            self.mark_dirty()
            self.redraw()

    def on_mouse_up(self, _event):
            self.drag_mode = None
            self.drag_start = None
            self.drag_original = None

    def clamp_box(self, key: str):
            if self.original_image is None:
                return
            iw, ih = self.original_image.size
            x, y, w, h = self.boxes[key]
            w = max(10, min(w, iw))
            h = max(10, min(h, ih))
            x = max(0, min(x, iw - w))
            y = max(0, min(y, ih - h))
            self.boxes[key] = [int(x), int(y), int(w), int(h)]

    def nudge(self, dx: int, dy: int):
            if self.preview_mode != "current" or not self.properties_editing or self.original_image is None:
                return
            self.push_undo()
            key = self.selected_box.get()
            x, y, w, h = self.boxes[key]
            self.boxes[key] = [x + dx, y + dy, w, h]
            self.clamp_box(key)
            self.mark_dirty()
            self.redraw()
