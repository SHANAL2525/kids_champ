import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

from .template_layout import TemplateLayoutMixin
from .template_state import TemplateStateMixin
from .template_actions import TemplateActionsMixin
from .template_canvas import TemplateCanvasMixin

class TemplateSettingsPanel(
    TemplateLayoutMixin,
    TemplateStateMixin,
    TemplateActionsMixin,
    TemplateCanvasMixin,
    tk.Frame,
):
    BOX_COLORS = {"artwork_box": "#16A34A", "name_box": PRIMARY, "city_box": ORANGE}
    BOX_LABELS = {"artwork_box": "Artwork", "name_box": "Name", "city_box": "Location"}
    def __init__(self, parent, app):
            super().__init__(parent, bg=BG)
            self.app = app
            self.template_records: Dict[str, Tuple[Path, dict]] = {}
            self.current_json_path: Optional[Path] = None
            self.template_image_path: Optional[Path] = None
            self.original_image: Optional[Image.Image] = None
            self.photo = None
            self.template_thumbnails: Dict[str, ImageTk.PhotoImage] = {}
            self.scale = 1.0
            self.offset_x = 0.0
            self.offset_y = 0.0
            self.boxes = {
                "artwork_box": [100, 100, 500, 500],
                "name_box": [100, 650, 500, 80],
                "city_box": [100, 740, 500, 60],
            }
            self.selected_box = tk.StringVar(value="artwork_box")
            self.drag_mode = None
            self.drag_start = None
            self.drag_original = None
            self.undo_stack: List[dict] = []
            self.saved_state: Optional[dict] = None
            self.preview_mode = "current"
            self.properties_editing = False
            self.dirty = False

            self.template_name = tk.StringVar(value="New Template")
            self.template_type = tk.StringVar(value="Portrait")
            self.artwork_fit_mode = tk.StringVar(value="Fill Frame")
            self.name_font_size = tk.IntVar(value=53)
            self.city_font_size = tk.IntVar(value=37)
            self.text_color = tk.StringVar(value="#10344B")
            self.show_location_pin = tk.BooleanVar(value=True)
            self.location_pin_size = tk.IntVar(value=38)
            self.location_pin_gap = tk.IntVar(value=12)
            self.sample_name = tk.StringVar(value="SAMPLE CHILD NAME")
            self.sample_city = tk.StringVar(value="COLOMBO")
            self.box_values = tk.StringVar(value="")
            self.unsaved_text = tk.StringVar(value="Saved")

            self._build_ui()
            self.refresh_template_list(select_first=True)
