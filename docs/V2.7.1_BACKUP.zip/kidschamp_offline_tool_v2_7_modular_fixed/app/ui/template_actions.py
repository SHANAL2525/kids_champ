import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class TemplateActionsMixin:
    def refresh_template_list(self, select_first: bool = False):
            current_stem = self.current_json_path.stem if self.current_json_path else None
            self.template_records = {}
            for path in sorted(TEMPLATE_DIR.glob("*.json")):
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    self.template_records[path.stem] = (path, data)
                except Exception:
                    continue
            self.template_tree.delete(*self.template_tree.get_children())
            self.template_thumbnails.clear()
            for stem, (path, data) in self.template_records.items():
                image_path = TEMPLATE_DIR / data.get("template_image", "")
                thumb = None
                try:
                    image = Image.open(image_path).convert("RGBA")
                    image.thumbnail((42, 42), Image.Resampling.LANCZOS)
                    thumb = ImageTk.PhotoImage(image)
                    self.template_thumbnails[stem] = thumb
                except Exception:
                    pass
                is_default = bool(data.get("is_default", stem in {"portrait", "landscape"}))
                name = data.get("name", stem)
                display_name = f"★ {name}" if is_default else name
                actions = "🔒 Protected" if is_default else "✎ Edit   × Delete"
                self.template_tree.insert(
                    "",
                    "end",
                    iid=stem,
                    text=display_name,
                    image=thumb,
                    values=(data.get("type", "Any"), actions),
                    tags=("default",) if is_default else (),
                )
            self.template_tree.tag_configure("default", foreground=PRIMARY_DARK)
            target = current_stem if current_stem in self.template_records else None
            if target is None and select_first and self.template_records:
                target = next(iter(self.template_records))
            if target:
                self.template_tree.selection_set(target)
                self.template_tree.focus(target)
                self.template_tree.see(target)
                self.load_template(*self.template_records[target])

    def on_template_tree_click(self, event):
            row = self.template_tree.identify_row(event.y)
            column = self.template_tree.identify_column(event.x)
            if not row:
                return
            if column != "#3":
                return
            path, data = self.template_records[row]
            is_default = bool(data.get("is_default", row in {"portrait", "landscape"}))
            bbox = self.template_tree.bbox(row, "actions")
            if not bbox:
                return
            if is_default:
                self.app.set_status("Default Portrait and Landscape templates are protected from deletion.")
                return "break"
            relative_x = event.x - bbox[0]
            if relative_x < bbox[2] * 0.48:
                self.template_tree.selection_set(row)
                self.load_template(path, data)
                self.set_properties_enabled(True)
            else:
                self.delete_template(path, data)
            return "break"

    def on_template_select(self, _event=None):
            selected = self.template_tree.selection()
            if not selected:
                return
            path, data = self.template_records[selected[0]]
            self.load_template(path, data)

    def load_template(self, path: Path, data: dict):
            if self.dirty:
                proceed = messagebox.askyesno("Unsaved changes", "Discard unsaved template changes and open another template?")
                if not proceed:
                    return
            self.current_json_path = path
            self.template_name.set(data.get("name", path.stem))
            self.template_type.set(data.get("type", "Any"))
            self.artwork_fit_mode.set(data.get("artwork_fit_mode", "Fill Frame"))
            self.name_font_size.set(int(data.get("name_font_size", 53)))
            self.city_font_size.set(int(data.get("city_font_size", 37)))
            self.text_color.set(data.get("text_color", "#10344B"))
            self.show_location_pin.set(bool(data.get("show_location_pin", True)))
            self.location_pin_size.set(int(data.get("location_pin_size", 38)))
            self.location_pin_gap.set(int(data.get("location_pin_gap", 12)))
            self.boxes = {
                "artwork_box": list(self._box_values(data.get("artwork_box", {}), [100, 100, 500, 500])),
                "name_box": list(self._box_values(data.get("name_box", {}), [100, 650, 500, 80])),
                "city_box": list(self._box_values(data.get("city_box", {}), [100, 740, 500, 60])),
            }
            image_path = TEMPLATE_DIR / data.get("template_image", "")
            try:
                self.original_image = Image.open(image_path).convert("RGBA")
                self.template_image_path = image_path
            except Exception as exc:
                self.original_image = None
                messagebox.showerror("Template image error", str(exc))
            self.saved_state = self.capture_state()
            self.undo_stack.clear()
            self.mark_saved()
            self.set_properties_enabled(False)
            self.preview_mode = "current"
            self.update_preview_toggle_styles()
            self.upload_template_button.configure(text="Replace image")
            self.redraw()

    @staticmethod
    def _box_values(data: dict, fallback: List[int]):
            return (
                int(data.get("x", fallback[0])),
                int(data.get("y", fallback[1])),
                int(data.get("width", fallback[2])),
                int(data.get("height", fallback[3])),
            )

    def new_template(self):
            if self.dirty and not messagebox.askyesno("Unsaved changes", "Discard current unsaved changes and create a new template?"):
                return
            self.push_undo()
            try:
                self.template_tree.selection_remove(self.template_tree.selection())
            except Exception:
                pass
            self.current_json_path = None
            self.template_image_path = None
            self.original_image = None
            self.template_name.set("New Template")
            self.template_type.set("Portrait")
            self.artwork_fit_mode.set("Fill Frame")
            self.name_font_size.set(53)
            self.city_font_size.set(37)
            self.text_color.set("#10344B")
            self.show_location_pin.set(True)
            self.location_pin_size.set(38)
            self.location_pin_gap.set(12)
            self.boxes = {
                "artwork_box": [100, 100, 500, 500],
                "name_box": [100, 650, 500, 80],
                "city_box": [100, 740, 500, 60],
            }
            self.saved_state = None
            self.mark_dirty()
            self.set_properties_enabled(True)
            self.upload_template_button.configure(text="Upload image")
            self.set_preview_mode("current")
            self.redraw()
            self.name_entry.focus_set()
            self.app.set_status("New template started. Upload a template image, adjust boxes, then Save changes.")

    def upload_template(self):
            path = filedialog.askopenfilename(
                title="Choose template image",
                filetypes=[("Template images", "*.png *.jpg *.jpeg *.tif *.tiff *.webp *.bmp")],
            )
            if not path:
                return
            self.push_undo()
            try:
                self.original_image = ImageOps.exif_transpose(Image.open(path)).convert("RGBA")
                self.template_image_path = Path(path)
            except Exception as exc:
                messagebox.showerror("Image error", str(exc))
                return
            iw, ih = self.original_image.size
            self.boxes = {
                "artwork_box": [int(iw * 0.1), int(ih * 0.1), int(iw * 0.8), int(ih * 0.58)],
                "name_box": [int(iw * 0.18), int(ih * 0.72), int(iw * 0.64), int(ih * 0.08)],
                "city_box": [int(iw * 0.24), int(ih * 0.81), int(iw * 0.52), int(ih * 0.07)],
            }
            self.mark_dirty()
            self.set_properties_enabled(True)
            self.redraw()

    def delete_template(self, path: Path, data: dict):
            name = data.get("name", path.stem)
            if not messagebox.askyesno("Delete template", f"Delete '{name}'?\n\nThis cannot be undone."):
                return
            try:
                image_path = TEMPLATE_DIR / data.get("template_image", "")
                path.unlink(missing_ok=True)
                if image_path.exists():
                    image_path.unlink()
                self.dirty = False
                self.current_json_path = None
                self.original_image = None
                self.refresh_template_list(select_first=True)
                self.app.reload_templates(silent=True)
                self.app.set_status(f"Deleted template: {name}")
            except Exception as exc:
                messagebox.showerror("Delete failed", str(exc))

    def save_template(self):
            if self.original_image is None:
                messagebox.showwarning("No template image", "Upload a template image first.")
                return
            name = self.template_name.get().strip()
            if not name:
                messagebox.showwarning("Missing name", "Enter a template name.")
                return
            if self.current_json_path is None:
                stem = slugify(name)
                json_path = TEMPLATE_DIR / f"{stem}.json"
                counter = 2
                while json_path.exists():
                    json_path = TEMPLATE_DIR / f"{stem}_{counter}.json"
                    counter += 1
                is_default = False
            else:
                json_path = self.current_json_path
                try:
                    existing = json.loads(json_path.read_text(encoding="utf-8"))
                    is_default = bool(existing.get("is_default", json_path.stem in {"portrait", "landscape"}))
                except Exception:
                    is_default = json_path.stem in {"portrait", "landscape"}
            image_path = TEMPLATE_DIR / f"{json_path.stem}.png"
            self.original_image.save(image_path, format="PNG")
            data = {
                "name": name,
                "type": self.template_type.get(),
                "artwork_fit_mode": self.artwork_fit_mode.get(),
                "is_default": is_default,
                "template_image": image_path.name,
                "artwork_box": self.box_dict("artwork_box"),
                "name_box": self.box_dict("name_box"),
                "city_box": self.box_dict("city_box"),
                "name_font_size": int(self.name_font_size.get()),
                "city_font_size": int(self.city_font_size.get()),
                "text_color": self.text_color.get(),
                "show_location_pin": bool(self.show_location_pin.get()),
                "location_pin_size": int(self.location_pin_size.get()),
                "location_pin_gap": int(self.location_pin_gap.get()),
            }
            try:
                json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            except Exception as exc:
                messagebox.showerror("Save failed", str(exc))
                return
            self.current_json_path = json_path
            self.template_image_path = image_path
            self.saved_state = self.capture_state()
            self.mark_saved()
            self.set_properties_enabled(False)
            self.refresh_template_list()
            if json_path.stem in self.template_tree.get_children():
                self.template_tree.selection_set(json_path.stem)
                self.template_tree.focus(json_path.stem)
            self.app.reload_templates(silent=True)
            self.app.set_status(f"Template saved and applied: {name}")

    def box_dict(self, key: str) -> dict:
            x, y, w, h = self.boxes[key]
            return {"x": int(x), "y": int(y), "width": int(w), "height": int(h)}

    def choose_color(self):
            if not self.properties_editing:
                return
            selected = colorchooser.askcolor(color=self.text_color.get(), title="Choose text colour")
            if selected and selected[1]:
                self.push_undo()
                self.text_color.set(selected[1])
                self.mark_dirty()
                self.redraw()

    def set_preview_mode(self, mode: str):
            if mode == "saved" and self.saved_state is None:
                self.app.set_status("This new template has not been saved yet.")
                return
            self.preview_mode = mode
            self.update_preview_toggle_styles()
            self.redraw()

    def update_preview_toggle_styles(self):
            if self.preview_mode == "current":
                set_button_colors(self.current_view_btn, PRIMARY, "white", PRIMARY_DARK)
                set_button_colors(self.saved_view_btn, CARD_ALT, MUTED, "#EEF2F7")
            else:
                set_button_colors(self.saved_view_btn, PRIMARY, "white", PRIMARY_DARK)
                set_button_colors(self.current_view_btn, CARD_ALT, MUTED, "#EEF2F7")
