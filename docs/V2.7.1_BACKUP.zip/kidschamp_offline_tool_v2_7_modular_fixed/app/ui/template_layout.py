import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class TemplateLayoutMixin:
    def _build_ui(self):
            top = tk.Frame(self, bg=BG, padx=18, pady=14)
            top.pack(fill="x")
            tk.Label(top, text="Template Settings", bg=BG, fg=TEXT, font=("Segoe UI", 20, "bold")).pack(side="left")
            folder_icon = self.app.icons.get("folder")
            open_folder_btn = make_button(
                top,
                "Open template folder",
                lambda: open_in_file_manager(TEMPLATE_DIR),
                icon=folder_icon,
                bg=CARD,
                fg=TEXT,
                active_bg=CARD_ALT,
                padx=12,
                pady=7,
            )
            open_folder_btn.pack(side="right")

            body = tk.Frame(self, bg=BG, padx=18)
            body.pack(fill="both", expand=True)
            body.grid_columnconfigure(0, weight=2, minsize=260)
            body.grid_columnconfigure(1, weight=6, minsize=520)
            body.grid_columnconfigure(2, weight=3, minsize=310)
            body.grid_rowconfigure(0, weight=1)

            # Left: template list and creation actions.
            left = tk.Frame(body, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
            left_top = tk.Frame(left, bg=CARD, padx=12, pady=12)
            left_top.pack(fill="x")
            tk.Label(left_top, text="Saved templates", bg=CARD, fg=TEXT, font=("Segoe UI", 14, "bold")).pack(anchor="w")
            action_row = tk.Frame(left_top, bg=CARD)
            action_row.pack(fill="x", pady=(10, 0))
            self.new_template_button = make_button(
                action_row,
                "New template",
                self.new_template,
                icon=self.app.icons.get("plus"),
                bg=PRIMARY_SOFT,
                fg=PRIMARY_DARK,
                active_bg="#DCE8FF",
                padx=9,
                pady=7,
                border_color=None,
                font=("Segoe UI", 10, "bold"),
            )
            self.new_template_button.pack(side="left", fill="x", expand=True, padx=(0, 5))
            self.upload_template_button = make_button(
                action_row,
                "Upload image",
                self.upload_template,
                icon=self.app.icons.get("imageic"),
                bg=CARD_ALT,
                fg=TEXT,
                active_bg="#EEF2F7",
                padx=8,
                pady=7,
                font=("Segoe UI", 10, "bold"),
            )
            self.upload_template_button.pack(side="left", fill="x", expand=True, padx=(5, 0))

            template_tree_wrap = tk.Frame(left, bg=CARD, padx=12, pady=12)
            template_tree_wrap.pack(fill="both", expand=True)
            columns = ("type", "actions")
            self.template_tree = ttk.Treeview(template_tree_wrap, columns=columns, show="tree headings", selectmode="browse", style="Template.Treeview")
            self.template_tree.heading("#0", text="Template")
            self.template_tree.heading("type", text="Type")
            self.template_tree.heading("actions", text="Actions")
            self.template_tree.column("#0", width=150, minwidth=120, anchor="w")
            self.template_tree.column("type", width=82, minwidth=70, anchor="center")
            self.template_tree.column("actions", width=90, minwidth=80, anchor="center")
            scrollbar = ttk.Scrollbar(template_tree_wrap, orient="vertical", command=self.template_tree.yview)
            self.template_tree.configure(yscrollcommand=scrollbar.set)
            self.template_tree.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            self.template_tree.bind("<<TreeviewSelect>>", self.on_template_select)
            self.template_tree.bind("<Button-1>", self.on_template_tree_click, add="+")

            # Centre: visual editor.
            center = tk.Frame(body, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            center.grid(row=0, column=1, sticky="nsew", padx=10)
            center_top = tk.Frame(center, bg=CARD, padx=14, pady=10)
            center_top.pack(fill="x")
            tk.Label(center_top, text="Visual editor", bg=CARD, fg=TEXT, font=("Segoe UI", 14, "bold")).pack(side="left")
            self.unsaved_label = tk.Label(center_top, textvariable=self.unsaved_text, bg=SUCCESS_SOFT, fg=SUCCESS, font=("Segoe UI", 9, "bold"), padx=8, pady=4)
            self.unsaved_label.pack(side="left", padx=(10, 0))
            self.saved_view_btn = make_button(
                center_top,
                "Last saved",
                lambda: self.set_preview_mode("saved"),
                bg=CARD_ALT,
                fg=MUTED,
                active_bg="#EEF2F7",
                padx=10,
                pady=6,
                font=("Segoe UI", 9, "bold"),
            )
            self.saved_view_btn.pack(side="right", padx=(5, 0))
            self.current_view_btn = make_button(
                center_top,
                "Current preview",
                lambda: self.set_preview_mode("current"),
                bg=PRIMARY,
                fg="white",
                active_bg=PRIMARY_DARK,
                padx=10,
                pady=6,
                border_color=None,
                font=("Segoe UI", 9, "bold"),
            )
            self.current_view_btn.pack(side="right")

            self.canvas = tk.Canvas(center, bg=CHARCOAL, highlightthickness=0, cursor="crosshair")
            self.canvas.pack(fill="both", expand=True, padx=12, pady=(0, 12))
            self.canvas.bind("<Configure>", lambda _e: self.redraw())
            self.canvas.bind("<ButtonPress-1>", self.on_mouse_down)
            self.canvas.bind("<B1-Motion>", self.on_mouse_move)
            self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
            self.canvas.bind("<Up>", lambda _e: self.nudge(0, -1))
            self.canvas.bind("<Down>", lambda _e: self.nudge(0, 1))
            self.canvas.bind("<Left>", lambda _e: self.nudge(-1, 0))
            self.canvas.bind("<Right>", lambda _e: self.nudge(1, 0))

            # Right: properties, collapsed/read-only until Edit.
            right = tk.Frame(body, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
            right.grid(row=0, column=2, sticky="nsew", padx=(10, 0))
            right_header = tk.Frame(right, bg=CARD, padx=14, pady=12)
            right_header.pack(fill="x")
            tk.Label(right_header, text="Template properties", bg=CARD, fg=TEXT, font=("Segoe UI", 14, "bold")).pack(side="left")
            self.edit_properties_button = make_button(
                right_header,
                "Edit",
                self.toggle_properties_edit,
                icon=self.app.icons.get("edit"),
                bg=PRIMARY_SOFT,
                fg=PRIMARY_DARK,
                active_bg="#DCE8FF",
                padx=9,
                pady=6,
                border_color=None,
                font=("Segoe UI", 9, "bold"),
            )
            self.edit_properties_button.pack(side="right")

            properties_canvas = tk.Canvas(right, bg=CARD, highlightthickness=0)
            properties_scroll = ttk.Scrollbar(right, orient="vertical", command=properties_canvas.yview)
            properties_canvas.configure(yscrollcommand=properties_scroll.set)
            properties_canvas.pack(side="left", fill="both", expand=True)
            properties_scroll.pack(side="right", fill="y")
            self.properties_body = tk.Frame(properties_canvas, bg=CARD, padx=14, pady=14)
            properties_window = properties_canvas.create_window((0, 0), window=self.properties_body, anchor="nw")
            self.properties_body.bind("<Configure>", lambda _e: properties_canvas.configure(scrollregion=properties_canvas.bbox("all")))
            properties_canvas.bind("<Configure>", lambda e: properties_canvas.itemconfigure(properties_window, width=e.width))
            def _properties_wheel(event):
                properties_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            properties_canvas.bind("<Enter>", lambda _e: self.app.bind_all("<MouseWheel>", _properties_wheel))
            properties_canvas.bind("<Leave>", lambda _e: self.app.unbind_all("<MouseWheel>"))
            self.properties_body.bind("<Enter>", lambda _e: self.app.bind_all("<MouseWheel>", _properties_wheel))
            self.properties_body.bind("<Leave>", lambda _e: self.app.unbind_all("<MouseWheel>"))

            self.property_widgets: List[tk.Widget] = []
            self.name_entry = self._property_entry("Template name", self.template_name)
            self.type_combo = self._property_combo("Template type", self.template_type, ["Portrait", "Landscape", "Any"])
            self.fit_combo = self._property_combo("Artwork placement", self.artwork_fit_mode, ["Fill Frame", "Fit Full Artwork"])
            tk.Label(
                self.properties_body,
                text="Fill Frame removes white gaps but may crop a small amount at the edges. Fit Full Artwork never crops, but can leave empty space.",
                bg=CARD, fg=MUTED, justify="left", wraplength=285, font=("Segoe UI", 9),
            ).pack(anchor="w", pady=(4, 2))

            tk.Label(self.properties_body, text="Editable boxes", bg=CARD, fg=TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(16, 6))
            box_row = tk.Frame(self.properties_body, bg=CARD)
            box_row.pack(fill="x")
            self.box_buttons: Dict[str, tk.Button] = {}
            for key, label in (("artwork_box", "Artwork"), ("name_box", "Name"), ("city_box", "Location")):
                button = make_button(
                    box_row,
                    label,
                    lambda k=key: self.select_box(k),
                    bg=CARD_ALT,
                    fg=TEXT,
                    active_bg="#EEF2F7",
                    padx=7,
                    pady=6,
                    font=("Segoe UI", 9, "bold"),
                )
                button.pack(side="left", fill="x", expand=True, padx=2)
                self.box_buttons[key] = button
            self.update_box_button_styles()
            tk.Label(self.properties_body, textvariable=self.box_values, bg=CARD, fg=MUTED, justify="left", font=("Consolas", 10)).pack(anchor="w", pady=(8, 0))
            tk.Label(
                self.properties_body,
                text="Drag inside a box to move it. Drag its bottom-right handle to resize. Arrow keys move 1 pixel.",
                bg=CARD,
                fg=MUTED,
                justify="left",
                wraplength=285,
                font=("Segoe UI", 9),
            ).pack(anchor="w", pady=(4, 0))

            self._property_spin("Name font size", self.name_font_size, 10, 150)
            self._property_spin("Location font size", self.city_font_size, 10, 150)
            pin_check = tk.Checkbutton(
                self.properties_body,
                text="Show location pin",
                variable=self.show_location_pin,
                command=self.on_property_change,
                bg=CARD,
                fg=TEXT,
                activebackground=CARD,
                selectcolor=CARD,
                font=("Segoe UI", 10),
                anchor="w",
            )
            pin_check.pack(fill="x", pady=(12, 2))
            self.property_widgets.append(pin_check)
            self._property_spin("Location pin size", self.location_pin_size, 12, 100)
            self._property_spin("Pin-to-text gap", self.location_pin_gap, 0, 50)

            color_row = tk.Frame(self.properties_body, bg=CARD)
            color_row.pack(fill="x", pady=(12, 0))
            tk.Label(color_row, text="Text colour", bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w")
            self.color_button = make_button(
                color_row,
                "Choose colour",
                self.choose_color,
                bg=CARD_ALT,
                fg=TEXT,
                active_bg="#EEF2F7",
                padx=9,
                pady=6,
                font=("Segoe UI", 9, "bold"),
            )
            self.color_button.pack(fill="x", pady=(4, 0))
            self.property_widgets.append(self.color_button)
            self.color_label = tk.Label(color_row, textvariable=self.text_color, bg=CARD, fg=MUTED, font=("Consolas", 9))
            self.color_label.pack(anchor="w", pady=(4, 0))
            self._property_entry("Sample name", self.sample_name)
            self._property_entry("Sample location", self.sample_city)

            # Bottom action bar stays clear of the corner.
            bottom = tk.Frame(self, bg=BG, padx=18, pady=14)
            bottom.pack(fill="x", side="bottom", before=body)
            self.undo_button = make_button(
                bottom,
                "Undo",
                self.undo,
                icon=self.app.icons.get("undo"),
                bg=CARD,
                fg=TEXT,
                active_bg=CARD_ALT,
                padx=13,
                pady=8,
            )
            self.undo_button.pack(side="left")
            self.save_button = make_button(
                bottom,
                "Save changes",
                self.save_template,
                icon=self.app.icons.get("save_white"),
                bg=PRIMARY,
                fg="white",
                active_bg=PRIMARY_DARK,
                border_color=None,
                padx=18,
                pady=9,
            )
            self.save_button.pack(side="right")
            self.set_properties_enabled(False)

    def _property_label(self, text: str):
            tk.Label(self.properties_body, text=text, bg=CARD, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(12, 4))

    def _property_entry(self, label: str, variable: tk.Variable):
            self._property_label(label)
            entry = tk.Entry(
                self.properties_body,
                textvariable=variable,
                font=("Segoe UI", 10),
                bg="#FFFFFF",
                fg=TEXT,
                relief="solid",
                bd=1,
                highlightthickness=0,
            )
            entry.pack(fill="x", ipady=7)
            entry.bind("<FocusIn>", self.push_undo_once)
            entry.bind("<KeyRelease>", self.on_property_change)
            self.property_widgets.append(entry)
            return entry

    def _property_combo(self, label: str, variable: tk.Variable, values: List[str]):
            self._property_label(label)
            combo = ttk.Combobox(self.properties_body, textvariable=variable, values=values, state="readonly")
            combo.pack(fill="x", ipady=5)
            combo.bind("<<ComboboxSelected>>", self.on_property_change)
            self.property_widgets.append(combo)
            return combo

    def _property_spin(self, label: str, variable: tk.Variable, low: int, high: int):
            self._property_label(label)
            spin = ttk.Spinbox(self.properties_body, from_=low, to=high, textvariable=variable, command=self.on_property_change)
            spin.pack(fill="x", ipady=5)
            spin.bind("<FocusIn>", self.push_undo_once)
            spin.bind("<KeyRelease>", self.on_property_change)
            self.property_widgets.append(spin)
            return spin

    def set_properties_enabled(self, enabled: bool):
            self.properties_editing = enabled
            for widget in self.property_widgets:
                try:
                    if isinstance(widget, ttk.Combobox):
                        widget.configure(state="readonly" if enabled else "disabled")
                    elif isinstance(widget, ttk.Spinbox):
                        widget.configure(state="normal" if enabled else "disabled")
                    else:
                        widget.configure(state="normal" if enabled else "disabled")
                except tk.TclError:
                    pass
            for button in self.box_buttons.values():
                button.configure(state="normal" if enabled else "disabled")
            self.edit_properties_button.configure(text="Done" if enabled else "Edit")

    def toggle_properties_edit(self):
            self.set_properties_enabled(not self.properties_editing)
            if self.properties_editing:
                self.set_preview_mode("current")
                self.name_entry.focus_set()

    def select_box(self, key: str):
            self.selected_box.set(key)
            self.update_box_button_styles()
            self.redraw()

    def update_box_button_styles(self):
            for key, button in self.box_buttons.items():
                if key == self.selected_box.get():
                    set_button_colors(button, self.BOX_COLORS[key], "white", self.BOX_COLORS[key])
                else:
                    set_button_colors(button, CARD_ALT, TEXT, "#EEF2F7")
