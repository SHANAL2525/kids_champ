import json
import os
import queue
import shutil
import tempfile
import threading
import zipfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

from ..config import *
from ..models import *
from ..template_store import choose_layout, load_template_layouts
from ..filename_parser import *
from ..image_renderer import *
from ..file_utils import *
from ..ui_helpers import *
from .. import template_store

class OutputActionsMixin:
    def preview_selected(self):
            self.canvas.delete("all")
            if not self.batch_items:
                self.canvas.create_text(30, 30, anchor="nw", fill="white", font=("Segoe UI", 14, "bold"), text="Drop a batch ZIP above to begin.")
                return
            if self.preview_index >= len(self.batch_items):
                self.preview_index = 0
            item = self.batch_items[self.preview_index]
            if item.status != "Ready":
                self.canvas.create_text(
                    24,
                    24,
                    anchor="nw",
                    fill="#FCA5A5",
                    font=("Segoe UI", 12, "bold"),
                    width=max(self.canvas.winfo_width() - 48, 280),
                    text=f"Cannot preview this item\n\n{item.filename}\n\n{item.warning}",
                )
                return
            try:
                output = render_item(item)
            except Exception as exc:
                self.canvas.create_text(24, 24, anchor="nw", fill="#FCA5A5", font=("Segoe UI", 12, "bold"), text=f"Preview failed:\n{exc}")
                return
            self.update_idletasks()
            canvas_width = max(self.canvas.winfo_width(), 300)
            canvas_height = max(self.canvas.winfo_height(), 300)
            margin = 20
            scale = min((canvas_width - margin * 2) / output.width, (canvas_height - margin * 2) / output.height)
            scale = max(scale, 0.05)
            display_size = (max(1, int(output.width * scale)), max(1, int(output.height * scale)))
            display = output.resize(display_size, Image.Resampling.LANCZOS)
            self.preview_photo = ImageTk.PhotoImage(display)
            x = (canvas_width - display_size[0]) // 2
            y = (canvas_height - display_size[1]) // 2
            self.canvas.create_image(x, y, anchor="nw", image=self.preview_photo)
            self.set_status(f"Preview: {item.child_name} · {item.city} · {item.template_mode} → {item.selected_layout}")

    def validate(self) -> Optional[str]:
            if not self.batch_items:
                return "Upload a batch ZIP first."
            if len(self.batch_items) > MAX_BATCH_IMAGES:
                return f"The maximum batch size is {MAX_BATCH_IMAGES} artworks."
            errors = [item for item in self.batch_items if item.status != "Ready"]
            if errors:
                return f"There are {len(errors)} filename or image errors. Edit or delete them before downloading."
            portrait_layout = template_store.choose_layout("Portrait")
            landscape_layout = template_store.choose_layout("Landscape")
            if not os.path.exists(portrait_layout.template_path) or not os.path.exists(landscape_layout.template_path):
                return "Default Portrait or Landscape template is missing. Open Template Settings and save it again."
            return None

    def generate_all(self):
            self.commit_inline_edit()
            error = self.validate()
            if error:
                messagebox.showwarning("Cannot download", error)
                return
            if self.is_generating:
                return
            output_dir = filedialog.askdirectory(title="Choose where to save the completed bulk output")
            if not output_dir:
                return
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = Path(output_dir) / f"KidsChamp_Final_{timestamp}"
            zip_path = Path(output_dir) / f"KidsChamp_Final_{timestamp}.zip"
            self.is_generating = True
            self.cancel_generation_event.clear()
            self.progress_value.set(0)
            self.set_status(f"Preparing {len(self.batch_items)} artworks...")
            self.update_button_states()
            worker = threading.Thread(target=self._generation_worker, args=(folder, zip_path), daemon=True)
            worker.start()
            self.after(100, self._poll_generation_queue)

    def _generation_worker(self, folder: Path, zip_path: Path):
            created: List[Path] = []
            mappings: List[Tuple[str, str]] = []
            failures: List[str] = []
            used_names = set()
            total = len(self.batch_items)
            try:
                folder.mkdir(parents=True, exist_ok=False)
                for index, item in enumerate(self.batch_items, start=1):
                    if self.cancel_generation_event.is_set():
                        raise InterruptedError("Generation cancelled by user.")
                    self.generation_queue.put(("progress", index, total, item.child_name))
                    try:
                        output = render_item(item)
                        filename = make_output_filename(item, used_names)
                        output_path = folder / filename
                        output.convert("RGB").save(output_path, format="PNG", compress_level=3)
                        created.append(output_path)
                        mappings.append((item.filename, output_path.name))
                    except Exception as exc:
                        failures.append(f"{item.filename}: {exc}")
                if self.cancel_generation_event.is_set():
                    raise InterruptedError("Generation cancelled by user.")
                manifest_lines = [
                    "Kids Champ Artwork Generator V2.7",
                    f"Generated: {datetime.now().isoformat(timespec='seconds')}",
                    f"Source ZIPs: {', '.join(str(p) for p in self.loaded_zip_paths)}",
                    f"Successful images: {len(created)}",
                    f"Failed images: {len(failures)}",
                    "",
                ]
                manifest_lines.extend(f"{source} -> {output}" for source, output in mappings)
                if failures:
                    manifest_lines += ["", "ERRORS:"] + failures
                manifest_path = folder / "generation_manifest.txt"
                manifest_path.write_text("\n".join(manifest_lines), encoding="utf-8")
                with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_STORED) as archive:
                    for index, path in enumerate(created, start=1):
                        if self.cancel_generation_event.is_set():
                            raise InterruptedError("Generation cancelled by user.")
                        self.generation_queue.put(("zipping", index, len(created), path.name))
                        archive.write(path, arcname=path.name)
                    archive.write(manifest_path, arcname=manifest_path.name)
                self.generation_queue.put(("done", {"folder": folder, "zip_path": zip_path, "created": created, "failures": failures}))
            except InterruptedError as exc:
                if zip_path.exists():
                    zip_path.unlink()
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
                self.generation_queue.put(("cancelled", str(exc)))
            except Exception as exc:
                if zip_path.exists():
                    zip_path.unlink()
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
                self.generation_queue.put(("fatal", str(exc)))

    def _poll_generation_queue(self):
            try:
                while True:
                    message = self.generation_queue.get_nowait()
                    kind = message[0]
                    if kind == "progress":
                        _, index, total, child_name = message
                        self.progress_value.set((index - 1) / max(total, 1) * 90)
                        self.set_status(f"Generating {index}/{total}: {child_name}")
                    elif kind == "zipping":
                        _, index, total, filename = message
                        self.progress_value.set(90 + (index / max(total, 1) * 10))
                        self.set_status(f"Creating bulk ZIP {index}/{total}: {filename}")
                    elif kind == "done":
                        result = message[1]
                        folder = result["folder"]
                        zip_path = result["zip_path"]
                        created = result["created"]
                        failures = result["failures"]
                        self.generated_paths.extend([folder, zip_path])
                        self.last_output_folder = folder
                        self.last_output_zip = zip_path
                        self.progress_value.set(100)
                        self.is_generating = False
                        self.update_button_states()
                        self.set_status(f"Finished: {len(created)} images · {zip_path.name}")
                        prompt = f"Created {len(created)} final images."
                        if failures:
                            prompt += f"\n{len(failures)} failed."
                        prompt += f"\n\nBulk ZIP:\n{zip_path}\n\nOpen the output folder now?"
                        if messagebox.askyesno("Download ready", prompt):
                            open_in_file_manager(folder)
                        return
                    elif kind == "cancelled":
                        self.is_generating = False
                        self.progress_value.set(0)
                        self.update_button_states()
                        self.set_status("Generation cancelled. Partial outputs were removed.")
                        messagebox.showinfo("Cancelled", "Generation stopped. Partial output files were removed.")
                        return
                    elif kind == "fatal":
                        self.is_generating = False
                        self.progress_value.set(0)
                        self.update_button_states()
                        self.set_status(f"Generation failed: {message[1]}")
                        messagebox.showerror("Generation error", message[1])
                        return
            except queue.Empty:
                pass
            if self.is_generating:
                self.after(100, self._poll_generation_queue)

    def cancel_generation(self):
            if not self.is_generating:
                return
            if messagebox.askyesno("Cancel generation", "Stop the current bulk generation? Partial output files will be deleted."):
                self.cancel_generation_event.set()
                self.set_status("Cancelling after the current artwork...")

    def _delete_generated_outputs(self) -> bool:
            failures = []
            for path in sorted([p for p in self.generated_paths if p.exists()], key=lambda p: len(str(p)), reverse=True):
                try:
                    if path.is_dir():
                        shutil.rmtree(path)
                    else:
                        path.unlink(missing_ok=True)
                except Exception as exc:
                    failures.append(f"{path}: {exc}")
            self.generated_paths = [path for path in self.generated_paths if path.exists()]
            if not self.generated_paths:
                self.last_output_folder = None
                self.last_output_zip = None
            if failures:
                messagebox.showwarning("Some files were not deleted", "\n".join(failures[:8]))
                return False
            return True

    def clear_all_images(self):
            if not self.batch_items and not self.generated_paths and not self.temp_dir:
                messagebox.showinfo("Nothing to clear", "There are no uploaded or generated images to clear.")
                return
            if not messagebox.askyesno(
                "Clear all",
                "Delete the uploaded batch, temporary artworks, previews, generated final images and bulk ZIP files?\n\nSaved templates will not be deleted.",
            ):
                return
            outputs_deleted = self._delete_generated_outputs()
            self.cleanup_temp()
            self.reset_batch_ui()
            if outputs_deleted:
                self.set_status("All uploaded and generated images were cleared. Templates are safe.")
                messagebox.showinfo("Cleared", "All session images were deleted. Saved templates were not deleted.")

    def on_close(self):
            if self.is_generating:
                if not messagebox.askyesno("Generation in progress", "Cancel the current generation and close the tool?"):
                    return
                self.cancel_generation_event.set()
                self.after(150, self._close_when_generation_stops)
                return
            self.cleanup_temp()
            self.destroy()

    def _close_when_generation_stops(self):
            if self.is_generating:
                self.after(150, self._close_when_generation_stops)
                return
            self.cleanup_temp()
            self.destroy()
