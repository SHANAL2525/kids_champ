import tkinter as tk
from typing import Optional
from PIL import Image, ImageTk
from .config import ICON_DIR, CARD, TEXT, BORDER

def load_icon(name: str, size: int = 20) -> Optional[ImageTk.PhotoImage]:
    path = ICON_DIR / f"{name}.png"
    try:
        image = Image.open(path).convert("RGBA")
        if image.size != (size, size):
            image = image.resize((size, size), Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(image)
    except Exception:
        return None

def make_button(
    parent,
    text: str,
    command,
    icon: Optional[ImageTk.PhotoImage] = None,
    bg: str = CARD,
    fg: str = TEXT,
    active_bg: Optional[str] = None,
    active_fg: Optional[str] = None,
    font=("Segoe UI", 11, "bold"),
    padx=14,
    pady=9,
    border_color: Optional[str] = BORDER,
):
    button = tk.Button(
        parent,
        text=text,
        command=command,
        image=icon,
        compound="left" if icon else None,
        font=font,
        bg=bg,
        fg=fg,
        activebackground=active_bg or bg,
        activeforeground=active_fg or fg,
        relief="flat",
        bd=0,
        padx=padx,
        pady=pady,
        cursor="hand2",
        highlightthickness=1 if border_color else 0,
        highlightbackground=border_color or bg,
        highlightcolor=border_color or bg,
    )
    button._normal_bg = bg  # type: ignore[attr-defined]
    button._hover_bg = active_bg or bg  # type: ignore[attr-defined]
    button.bind("<Enter>", lambda _e: button.configure(bg=button._hover_bg))
    button.bind("<Leave>", lambda _e: button.configure(bg=button._normal_bg))
    return button

def set_button_colors(button: tk.Button, bg: str, fg: str, hover: Optional[str] = None):
    button._normal_bg = bg  # type: ignore[attr-defined]
    button._hover_bg = hover or bg  # type: ignore[attr-defined]
    button.configure(bg=bg, fg=fg, activebackground=hover or bg, activeforeground=fg)
