"""Kids Champ V2.7 modular application package."""
