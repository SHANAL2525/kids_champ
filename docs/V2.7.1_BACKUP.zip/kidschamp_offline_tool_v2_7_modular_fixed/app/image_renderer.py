import os
from pathlib import Path
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw, ImageFont, ImageOps
from .models import Box, Layout, BatchItem
from .template_store import choose_layout
from .filename_parser import safe_name

def font_candidates(bold: bool = True, unicode_text: bool = False) -> List[str]:
    candidates: List[str] = []
    if os.name == "nt":
        if unicode_text:
            candidates += [
                r"C:\Windows\Fonts\NirmalaB.ttf",
                r"C:\Windows\Fonts\Nirmala.ttf",
                r"C:\Windows\Fonts\seguisb.ttf",
            ]
        if bold:
            candidates += [
                r"C:\Windows\Fonts\arialbd.ttf",
                r"C:\Windows\Fonts\seguisb.ttf",
                r"C:\Windows\Fonts\calibrib.ttf",
            ]
        candidates += [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf"]
    candidates += [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "DejaVuSans-Bold.ttf",
        "arialbd.ttf",
        "arial.ttf",
    ]
    return candidates

def load_font(size: int, text: str, bold: bool = True):
    unicode_text = any(ord(ch) > 127 for ch in text)
    for candidate in font_candidates(bold=bold, unicode_text=unicode_text):
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()

def fit_font(draw: ImageDraw.ImageDraw, text: str, box: Box, start_size: int, min_size: int = 14):
    for size in range(start_size, min_size - 1, -1):
        font = load_font(size, text, bold=True)
        bbox = draw.textbbox((0, 0), text, font=font)
        width = bbox[2] - bbox[0]
        height = bbox[3] - bbox[1]
        if width <= box.width and height <= box.height:
            return font, width, height, bbox
    font = load_font(min_size, text, bold=True)
    bbox = draw.textbbox((0, 0), text, font=font)
    return font, bbox[2] - bbox[0], bbox[3] - bbox[1], bbox

def draw_centered_text(draw: ImageDraw.ImageDraw, text: str, box: Box, start_size: int, color: str):
    display_text = text.upper()
    font, text_width, text_height, bbox = fit_font(draw, display_text, box, start_size)
    x = box.x + (box.width - text_width) / 2 - bbox[0]
    y = box.y + (box.height - text_height) / 2 - bbox[1]
    draw.text((x, y), display_text, font=font, fill=color)

def draw_location_pin(draw: ImageDraw.ImageDraw, x: float, y: float, size: int):
    size = max(12, int(size))
    red = "#FF3B30"
    dark_red = "#D92D20"
    white = "#FFFFFF"
    center_x = x + size * 0.50
    circle_center_y = y + size * 0.35
    outer_r = size * 0.28
    draw.polygon(
        [
            (center_x - outer_r * 0.70, circle_center_y + outer_r * 0.55),
            (center_x + outer_r * 0.70, circle_center_y + outer_r * 0.55),
            (center_x, y + size * 0.96),
        ],
        fill=dark_red,
    )
    draw.ellipse(
        (center_x - outer_r, circle_center_y - outer_r, center_x + outer_r, circle_center_y + outer_r),
        fill=red,
    )
    inner_r = outer_r * 0.38
    draw.ellipse(
        (center_x - inner_r, circle_center_y - inner_r, center_x + inner_r, circle_center_y + inner_r),
        fill=white,
    )

def draw_location_text(draw: ImageDraw.ImageDraw, text: str, layout: Layout):
    box = layout.city_box
    display_text = text.upper()
    if not layout.show_location_pin:
        draw_centered_text(draw, display_text, box, layout.city_font_size, layout.text_color)
        return

    pin_size = max(12, min(int(layout.location_pin_size), box.height))
    gap = max(0, int(layout.location_pin_gap))
    text_box_width = max(20, box.width - pin_size - gap)
    text_box = Box(0, 0, text_box_width, box.height)
    font, text_width, text_height, bbox = fit_font(draw, display_text, text_box, layout.city_font_size)
    total_width = pin_size + gap + text_width
    group_x = box.x + max(0, (box.width - total_width) / 2)
    pin_y = box.y + (box.height - pin_size) / 2
    draw_location_pin(draw, group_x, pin_y, pin_size)
    text_x = group_x + pin_size + gap - bbox[0]
    text_y = box.y + (box.height - text_height) / 2 - bbox[1]
    draw.text((text_x, text_y), display_text, font=font, fill=layout.text_color)

def place_full_artwork(base: Image.Image, artwork: Image.Image, box: Box, fit_mode: str = "Fill Frame"):
    artwork = ImageOps.exif_transpose(artwork).convert("RGBA")

    # Fill Frame removes the white bars that appear when the artwork aspect ratio
    # does not match the saved template box. Aspect ratio is preserved; only the
    # minimum amount needed at the edges is center-cropped.
    if fit_mode == "Fill Frame":
        fitted = ImageOps.fit(
            artwork,
            (box.width, box.height),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )
        base.alpha_composite(fitted, (box.x, box.y))
        return

    # Fit Full Artwork preserves every pixel of the artwork. If the aspect ratios
    # differ, empty space may remain around it.
    contained = ImageOps.contain(artwork, (box.width, box.height), method=Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (box.width, box.height), (255, 255, 255, 255))
    x = (box.width - contained.width) // 2
    y = (box.height - contained.height) // 2
    canvas.alpha_composite(contained, (x, y))
    base.alpha_composite(canvas, (box.x, box.y))

def render_item(item: BatchItem) -> Image.Image:
    layout = choose_layout(item.selected_layout)
    template = Image.open(layout.template_path).convert("RGBA")
    with Image.open(item.source_path) as artwork:
        place_full_artwork(template, artwork, layout.artwork_box, layout.artwork_fit_mode)
    draw = ImageDraw.Draw(template)
    draw_centered_text(draw, item.child_name, layout.name_box, layout.name_font_size, layout.text_color)
    draw_location_text(draw, item.city, layout)
    return template

def make_output_filename(item: BatchItem, used_names: set) -> str:
    if item.submission_id:
        base = f"{safe_name(item.submission_id)}__{safe_name(item.child_name)}__{safe_name(item.city)}"
    else:
        base = f"{safe_name(item.child_name)}__{safe_name(item.city)}"
    candidate = f"{base}.png"
    counter = 2
    while candidate.lower() in used_names:
        candidate = f"{base}_{counter}.png"
        counter += 1
    used_names.add(candidate.lower())
    return candidate
