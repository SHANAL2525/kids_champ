import json
import shutil
from typing import Dict
from .config import BUNDLED_TEMPLATE_DIR, TEMPLATE_DIR
from .models import Box, Layout

def ensure_default_templates() -> None:
    """Copy bundled templates to the editable app folder only when missing."""
    if not BUNDLED_TEMPLATE_DIR.exists():
        return
    for source in BUNDLED_TEMPLATE_DIR.iterdir():
        if source.suffix.lower() not in {".json", ".png", ".jpg", ".jpeg"}:
            continue
        destination = TEMPLATE_DIR / source.name
        if not destination.exists():
            try:
                shutil.copy2(source, destination)
            except OSError:
                pass

def _box_from_dict(data: dict) -> Box:
    return Box(
        int(data.get("x", 0)),
        int(data.get("y", 0)),
        int(data.get("width", 100)),
        int(data.get("height", 50)),
    )

def load_template_layouts() -> Dict[str, Layout]:
    layouts: Dict[str, Layout] = {}
    for json_path in sorted(TEMPLATE_DIR.glob("*.json")):
        try:
            data = json.loads(json_path.read_text(encoding="utf-8"))
            image_path = TEMPLATE_DIR / data.get("template_image", "")
            if not image_path.exists():
                continue
            layout = Layout(
                template_path=str(image_path),
                artwork_box=_box_from_dict(data.get("artwork_box", {})),
                name_box=_box_from_dict(data.get("name_box", {})),
                city_box=_box_from_dict(data.get("city_box", {})),
                name_font_size=int(data.get("name_font_size", 53)),
                city_font_size=int(data.get("city_font_size", 37)),
                text_color=data.get("text_color", "#10344B"),
                show_location_pin=bool(data.get("show_location_pin", True)),
                location_pin_size=int(data.get("location_pin_size", 38)),
                location_pin_gap=int(data.get("location_pin_gap", 12)),
                artwork_fit_mode=data.get("artwork_fit_mode", "Fill Frame"),
                display_name=data.get("name", json_path.stem),
                template_type=data.get("type", "Any"),
                is_default=bool(data.get("is_default", json_path.stem in {"portrait", "landscape"})),
            )
            layouts[layout.display_name] = layout
        except Exception:
            continue
    return layouts

def _first_layout(kind: str) -> Layout:
    exact = [layout for layout in TEMPLATE_LAYOUTS.values() if layout.template_type == kind]
    defaults = [layout for layout in exact if layout.is_default]
    if defaults:
        return defaults[0]
    if exact:
        return exact[0]
    any_layout = [layout for layout in TEMPLATE_LAYOUTS.values() if layout.template_type == "Any"]
    if any_layout:
        return any_layout[0]
    fallback_path = str(TEMPLATE_DIR / ("portrait.png" if kind == "Portrait" else "landscape.png"))
    fallback_box = Box(326, 110, 461, 591) if kind == "Portrait" else Box(148, 136, 841, 515)
    return Layout(
        fallback_path,
        fallback_box,
        Box(275, 720, 575, 82) if kind == "Portrait" else Box(300, 700, 560, 90),
        Box(375, 795, 475, 62) if kind == "Portrait" else Box(438, 785, 420, 66),
        53,
        37,
        display_name=kind,
        template_type=kind,
        is_default=True,
    )

def reload_template_cache() -> None:
    global TEMPLATE_LAYOUTS, PORTRAIT_LAYOUT, LANDSCAPE_LAYOUT
    TEMPLATE_LAYOUTS = load_template_layouts()
    PORTRAIT_LAYOUT = _first_layout("Portrait")
    LANDSCAPE_LAYOUT = _first_layout("Landscape")

def choose_layout(kind: str) -> Layout:
    return PORTRAIT_LAYOUT if kind == "Portrait" else LANDSCAPE_LAYOUT

ensure_default_templates()
TEMPLATE_LAYOUTS: Dict[str, Layout] = {}
PORTRAIT_LAYOUT: Layout
LANDSCAPE_LAYOUT: Layout
reload_template_cache()
