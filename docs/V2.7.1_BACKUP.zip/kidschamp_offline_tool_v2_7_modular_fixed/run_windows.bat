@echo off
cd /d "%~dp0"
title Kids Champ Artwork Generator V2.7.1 Modular Fixed
where py >nul 2>nul
if %errorlevel%==0 (
    py -m pip install -r requirements.txt
    py main.py
) else (
    python -m pip install -r requirements.txt
    python main.py
)
pause
